/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "15px",
      screens: {
        "2xl": "1520px",
      },
    },
    extend: {
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
      fontFamily: {
        sans: ["Gotham-Book"],
        GothamBold: ["Gotham-Bold"],
        GothamMedium: ["Gotham-Medium"],
        GothamBlack: ["Gotham-Black"],
        mono: ["Leviathan-HTF-Black"],
      },
      fontSize: {
        "28px": "28px",
        "48px": "48px",
        "70px": "70px",
        "73px": "73px",
        "82px": "82px",
        "95px": "95px",
        "112px": "112px",
      },
      lineHeight: {
        "extra-loose": "2.5",
        "102px": "6.375rem",
        "82px": "5.125rem",
      },
      spacing: {
        500: "500px",
      },

      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.5s ease-out",
        "accordion-up": "accordion-up 0.5s ease-out",
      },
    },
    screens: {
      "3xs": "320px",
      "2xs": "375px",
      xxs: "414px",
      xs: "480px",
      xsm: "540px",
      sm: "640px",
      md: "767.98px",
      mdtab: "991.98px",
      "md-820": "820px",
      lg: "1025px",
      "lg-1100": "1100.98px",
      "lg-1200": "1200px",
      xl: "1280px",
      "xl-1300": "1300px",
      "xl-1365": "1365px",
      "xl-1440": "1440px",
      "xl-1536": "1536px",
      "xxl-1600": "1600.98px",
      "xxl-1660": "1660px",
      "xxl-1710": "1710px",
      "xxl-1800": "1800px",
      "xxl-1850": "1850px",
      "xxl-1920": "1921px",
      "xxl-2300": "2300px",
      "xxl-2400": "2400px",
      "xxl-2700": "2700px",
      xxl: "1440px",
      "2xl": "1680px",
      "custom-max-md": { max: "767.98px" },
      "4xl": "1850px",
      "custom-max-2xl": { max: "1400px" },
      "custom-max-2xl-text": { max: "1365px" },
      "max-xs": { max: "480px" },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
