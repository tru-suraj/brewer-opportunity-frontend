import * as z from "zod";
const currentYear = new Date().getFullYear();
export const validateAgeForm = (day: number, month: number, year: number) => {
  // Check if any of the input parameters is not a number or falls out of range
  if (isNaN(day) || day < 1 || day > 31) {
    return "Date is invalid"; // Return invalid date message
  }

  if (isNaN(month) || month < 1 || month > 12) {
    return "Date is invalid"; // Return invalid date message
  }

  if (isNaN(year) || year < 1000 || year > 9999) {
    return "Date is invalid"; // Return invalid date message
  }

  // Create a Date object from the input parameters
  const bday = new Date(year, month - 1, day);

  // Check if the created date is the same as the input parameters
  if (
    bday.getFullYear() !== year ||
    bday.getMonth() !== month - 1 ||
    bday.getDate() !== day
  ) {
    return "Date is invalid"; // Return invalid date message
  }

  // Calculate age
  const todayDate = new Date();
  let age = todayDate.getFullYear() - bday.getFullYear();

  // Adjust age if the birthday hasn't occurred yet in the current year
  if (
    todayDate.getMonth() < bday.getMonth() ||
    (todayDate.getMonth() === bday.getMonth() &&
      todayDate.getDate() < bday.getDate())
  ) {
    age--;
  }

  // If age is less than 19, return appropriate message
  if (age < 19) {
    return "Age is less than 19";
  }

  // If all conditions pass, return true
  return true;
};
export const validateForm = (day: number, month: number, year: number) => {
  if (isNaN(day) || day < 1 || day > 31) {
    return false;
  }

  if (isNaN(month) || month < 1 || month > 12) {
    return false;
  }

  if (isNaN(year) || year < 1000 || year > 9999) {
    return false;
  }

  const bday = new Date(year, month - 1, day);

  if (
    bday.getFullYear() !== year ||
    bday.getMonth() !== month - 1 ||
    bday.getDate() !== day
  ) {
    return false;
  }

  const todayDate = new Date();
  let age = todayDate.getFullYear() - bday.getFullYear();

  if (
    todayDate.getMonth() < bday.getMonth() ||
    (todayDate.getMonth() === bday.getMonth() &&
      todayDate.getDate() < bday.getDate())
  ) {
    age--;
  }

  return age >= 19;
};
export const footerSubscribeSchema = z.object({
  email: z
    .string()
    .min(1, { message: "This field is required." })
    .email("Please enter a valid email address."),
});
export const newsletterSignupSchema = z.object({
  email: z
    .string()
    .min(1, { message: "This field is required." })
    .email("Please enter a valid email address."),
  overage: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: "This field is required.",
    }),
  marketingPermissions: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: "This field is required.",
    }),
});
export const contactUsSchema = z.object({
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z\s]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z\s]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  email: z
    .string()
    .min(1, { message: "This field is required." })
    .email("Please enter a valid email address."),
  services: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
  comments: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
});
export const programSchema = z.object({
  brandName: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z\s]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  container: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z\s]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  volume: z.string().min(1, { message: "This field is required." }),
  articleNumber: z.string().min(1, { message: "This field is required." }),
  skuPricing: z.string().min(1, { message: "This field is required." }),
  offers: z.string().min(1, { message: "This field is required." }),
  promoCase: z.string().min(1, { message: "This field is required." }),
  cycle: z.string().min(1, { message: "This field is required." }),
  packSize: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
  comments: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
    selectedZone: z.array(z.string()).refine((value) => value.some((item) => item), {
    message: "You have to select at least one zone.",
  }),
});
export const leaveReplySchema = z.object({
  username: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  email: z
    .string()
    .min(1, { message: "This field is required." })
    .email("Please enter a valid email address."),

  heading: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),

  review: z.string().default("").optional(),
});
export const contactUs = z.object({
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+$/.test(value), {
      message: "Please enter letters only.",
    }),
  email: z
    .string()
    .min(1, { message: "This field is required." })
    .email("Please enter a valid email address."),

  comments: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
});
export const billingAddressSchema = z.object({
  Province: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),

  Address: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .trim()
    .refine((value) => /^(0?[1-9]|1[0-9]|2[0-9]|3[0-1])$/.test(value), {
      message: "Please enter a valid date.",
    }),
  City: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .trim()
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  PostalCode: z
    .string({
      required_error: "This field is required",
    })
    .refine((value) => /^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$/.test(value), {
      message: "Please enter valid postal code only.",
    }),
});

export const deliveryAddressSchema = z.object({
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),

  Address: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .trim()
    .refine((value) => /^(0?[1-9]|1[0-9]|2[0-9]|3[0-1])$/.test(value), {
      message: "Please enter a valid date.",
    }),
  Buzzer: z.string().optional(),
});
export const registerSchema = z
  .object({
    email: z
      .string({ required_error: "This field is required." })
      .min(1, { message: "This field is required." })
      .email({ message: "Please enter a valid email address." }),
    password: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .trim()
      .min(
        8,
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /\d/.test(value),
        "Password must contain at least 1 number."
      )
      .refine(
        (value) => /[a-zA-Z]/.test(value),
        "Password must contain at least 1 letter."
      )
      .refine(
        (value) => /[!@#$%^&*]/.test(value),
        "Password must contain at least 1 special character (!,@,#,$,%,^,&,*)."
      ),
    confirmPassword: z.string({
      required_error: "This field is required.",
    }),
    Salutation: z
      .string({
        required_error: "This field is required.",
      })
      .refine((value) => value, {
        message: "This field is required.",
      }),
    firstname: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
        message: "Please enter letters only.",
      }),
    lastname: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
        message: "Please enter letters only.",
      }),
    phone: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .min(15, { message: "Invalid Phone Number." }),
    dobDay: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .trim()
      .refine((value) => /^(0?[1-9]|1[0-9]|2[0-9]|3[0-1])$/.test(value), {
        message: "Please enter a valid date.",
      }),
    dobMonth: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .trim()
      .refine((value) => /^(0?[1-9]|1[0-2])$/.test(value), {
        message: "Please enter a valid month.",
      }),
    dobYear: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .min(4, {
        message: "Please enter a valid year.",
      })
      .trim()
      .refine(
        (value) => {
          const birthYear = parseInt(value, 10);
          const age = currentYear - birthYear;
          return age >= 19; // Adjust this condition as needed
        },
        {
          message: "You must be over the age of 19 to continue.",
        }
      )
      .refine(
        (value) => {
          return Number(value) >= 1900;
        },
        {
          message: "Please enter a valid year.",
        }
      ),
    termsAndCondition: z.boolean().refine((Value) => Value === true, {
      message: "This field is required.",
    }),
    updateAndPromotions: z.boolean().default(false),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Password doesn't match.",
    path: ["confirmPassword"],
  });
export const contestSchema = z.object({
  email: z
    .string({ required_error: "This field is required." })
    .min(1, { message: "This field is required." })
    .email({ message: "Please enter a valid email address." }),
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  overAge: z
    .boolean()
    .default(false)
    .refine((value) => value === true, {
      message: "This field is required.",
    }),
  updateAndPromotions: z.boolean().default(false),
});

export const loginSchema = z.object({
  email: z
    .string()
    .min(1, {
      message: "This field is required.",
    })
    .email("Please enter a valid email address."),
  password: z.string().min(2, {
    message: "This field is required.",
  }),
});

export const billingAddressSchemaNew = z.object({
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  Address: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z0-9'.,:;# \[\]-]+$/.test(value), {
      message: "Please enter valid address.",
    }),
  City: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z.' -]*$/.test(value), {
      message: "Please enter valid city.",
    }),
  Province: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." }),
  PostalCode: z
    .string({
      required_error: "This field is required",
    })
    .trim()
    .refine(
      (value) =>
        /^(?!.*[DFIOQU])[A-VXY][0-9][A-Z] ?[0-9][A-Z][0-9]$/i.test(value),
      {
        message: "Please enter valid postal code only.",
      }
    ),
});

export const personalInfoSchema = z.object({
  email: z
    .string({ required_error: "This field is required." })
    .refine(
      (value) => /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(value),
      { message: "Please enter a valid email address." }
    ),

  Salutation: z
    .string({
      required_error: "This field is required.",
    })
    .refine((value) => value, {
      message: "This field is required.",
    }),
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  phone: z
    .string({
      required_error: "This field is required.",
    })
    .min(15, { message: "Invalid Phone Number." }),
  dobDay: z
    .string({
      required_error: "This field is required.",
    })
    .trim()
    .refine((value) => /^(0?[1-9]|1[0-9]|2[0-9]|3[0-1])$/.test(value), {
      message: "Please enter a valid date.",
    }),
  dobMonth: z
    .string({
      required_error: "This field is required.",
    })
    .trim()
    .refine((value) => /^(0?[1-9]|1[0-2])$/.test(value), {
      message: "Please enter a valid month.",
    }),
  dobYear: z
    .string({
      required_error: "This field is required.",
    })
    .min(4, {
      message: "Please enter a valid year.",
    })
    .trim()
    // .refine((value) => Number(value) < new Date().getFullYear() - 18, {
    //   message: 'Your age should be greater than or equals to 18.',
    // }),
    .refine(
      (value) => {
        const birthYear = parseInt(value, 10);
        const age = currentYear - birthYear;
        return age >= 19; // Adjust this condition as needed
      },
      {
        message: "Your age should be greater than or equals to 18.",
      }
    )
    .refine(
      (value) => {
        return Number(value) >= 1900;
      },
      {
        message: "Please enter a valid year.",
      }
    ),
  updateAndPromotions: z.boolean().default(false),
});
export const contestInfoSchema = z.object({
  ageConsent: z
    .boolean()
    .default(false)
    .refine((Value) => Value === true, {
      message: "This field is required.",
    }),
  updateAndPromotion: z.boolean().default(false).optional(),
});

export const cc_format = (value: string) => {
  var v = value?.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
  var matches = v?.match(/\d{4,16}/g);
  var match = (matches && matches[0]) || "";
  var parts = [];

  for (let i = 0, len = match.length; i < len; i += 4) {
    parts?.push(match.substring(i, i + 4));
  }

  if (parts?.length) {
    return parts?.join(" ");
  } else {
    return value;
  }
};
export const formatPhoneNumber = (value: string) => {
  let cleanedValue = value.replace("+1", "");
  cleanedValue = cleanedValue.replace("1(", "");
  cleanedValue = cleanedValue.replace(/\D/g, "").slice(0, 10); // Limit to 10 digits
  let formattedValue = cleanedValue.replace(
    /(\d{0,3})(\d{0,3})(\d{0,4})/,
    function (match, p1, p2, p3) {
      return "+1" + (!p2 ? p1 : "(" + p1 + ")") + p2 + (p3 ? "-" + p3 : "");
    }
  );
  return formattedValue;
};
export const formatCanadianPostalCode = (value: string) => {
  const cleanedValue = value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();

  if (cleanedValue.length <= 3) {
    return cleanedValue;
  }

  return cleanedValue.slice(0, 3) + " " + cleanedValue.slice(3);
};
export const formatPhoneNumberView = (value: string) => {
  const cleanedValue = value.replace(/\D/g, "").slice(0, 10); // Limit to 10 digits
  var formattedValue = cleanedValue.replace(
    /(\d{0,3})(\d{0,3})(\d{0,4})/,
    function (match, p1, p2, p3) {
      return "(" + p1 + ") " + (p2 ? p2 + "-" : "") + p3;
    }
  );
  return formattedValue;
};

export const formatPhoneNumberWithPrefix = (
  value: string,
  prefix: string = ""
) => {
  const cleanedValue = value.replace(/\D/g, "").slice(0, 11); // Limit to 10 digits
  var formattedValue = cleanedValue.replace(
    /(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,4})/,
    function (match, p1, p2, p3, p4) {
      return prefix + (!p3 ? p2 : "(" + p2 + ")") + p3 + (p4 ? "-" + p4 : "");
    }
  );
  return formattedValue;
};

export const resetPasswordSchema = z
  .object({
    password: z
      .string({
        required_error: "This field is required.",
      })
      .min(
        1,
        // 'Password must contain a minimum of 8 characters.'
        "This field is required."
      )
      .min(
        8,
        // 'Password must contain a minimum of 8 characters.'
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /\d/.test(value),
        // 'Password must contain at least 1 number.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[a-zA-Z]/.test(value),
        // 'Password must contain at least 1 letter.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[!@#$%^&*]/.test(value),
        // 'Password must contain at least 1 special character (!,@,#,$,%,^,&,*).',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      ),
    confirmPassword: z
      .string({
        required_error: "This field is required.",
      })
      .min(
        1,
        // 'Password must contain a minimum of 8 characters.'
        "This field is required."
      ),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match.",
    path: ["confirmPassword"],
  });

export const changePasswordSchema = z
  .object({
    currentPassword: z
      .string()
      .min(1, { message: "This field is required." })
      .min(
        8,
        // 'Password must contain a minimum of 8 characters.'
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /\d/.test(value),
        // 'Password must contain at least 1 number.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[a-zA-Z]/.test(value),
        // 'Password must contain at least 1 letter.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[!@#$%^&*]/.test(value),
        // 'Password must contain at least 1 special character (!,@,#,$,%,^,&,*).',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      ),
    newPassword: z
      .string({
        required_error: "This field is required.",
      })
      .min(1, { message: "This field is required." })
      .trim()
      .min(
        8,
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /\d/.test(value),
        // 'Password must contain at least 1 number.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[a-zA-Z]/.test(value),
        // 'Password must contain at least 1 letter.',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      )
      .refine(
        (value) => /[!@#$%^&*]/.test(value),
        // 'Password must contain at least 1 special character (!,@,#,$,%,^,&,*).',
        "Password must contain a minimum of 8 characters, at least 1 letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*)."
      ),
    reEnterPassword: z.string().min(1, { message: "This field is required." }),
  })
  .refine((data) => data?.newPassword === data?.reEnterPassword, {
    message: "Passwords do not match.",
    path: ["reEnterPassword"],
  });

export const checkGCBalance = z.object({
  cardNumber: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z0-9]+$/.test(value), {
      message: "Please enter letters or numbers only.",
    }),
});

export const formatDeliveryInstructions = (value: string) => {
  return value.replace(/[^a-zA-Z0-9!@#$%^&*()_+{}\[\]:;<>,.?~\\/\s-]/g, "");
};

export const deliveryAddressSchemaNew = z.object({
  firstname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  lastname: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .refine((value) => /^[a-zA-Z]+(?: [a-zA-Z]+)*$/.test(value), {
      message: "Please enter letters only.",
    }),
  Address: z
    .string({
      required_error: "This field is required.",
    })
    .min(1, { message: "This field is required." })
    .max(150, { message: "Invalid address" }),
  Buzzer: z.optional(z.string().max(350, { message: "Invalid buzzer" })),
});
