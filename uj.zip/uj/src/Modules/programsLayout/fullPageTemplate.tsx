import React from "react";
import { ContainerLayout, ContentLayout } from "./index";
import BannerHeader from "./bannerHeader";
import Layout from "../../pages/layout/layout";

interface FullPageTemplateProps {
  bannerTitle?: string | any;
  breadcrumbList?: [] | any;
  children?: React.ReactNode;
  bannerSubTitle?: string;
  desktopBg?: string;
  ipadBg?: string;
  mobileBg?: string;
  small?: boolean;
  mid?: boolean;
  className?: string;
}

export const FullPageTemplate: React.FC<FullPageTemplateProps> = ({
  bannerTitle,
  ipadBg,
  mobileBg,
  bannerSubTitle,
  breadcrumbList,
  desktopBg,
  children,
  small,
  mid,
  className = "",
}) => {
  return (
    <Layout>
      <BannerHeader
        title={bannerTitle}
        desktopBg={desktopBg}
        ipadBg={ipadBg}
        mobileBg={mobileBg}
        subtitle={bannerSubTitle}
        className={`${className}
            ${
              bannerTitle || desktopBg || ipadBg || mobileBg || bannerSubTitle
                ? small
                  ? "!min-h-[200px]"
                  : mid
                  ? "!min-h-[250px] md:!min-h-[200px]"
                  : ""
                : "hidden"
            }
          `}
      />

      <ContainerLayout className="container py-[80px]">
        <ContentLayout className="basis-full">{children}</ContentLayout>
      </ContainerLayout>
    </Layout>
  );
};
