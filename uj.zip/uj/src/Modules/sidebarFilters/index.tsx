import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../components/ui/accordion";
import { Button } from "../../components/ui/button";
import { Checkbox } from "../../components/ui/checkbox";
import { Input } from "../../components/ui/input";

import { ChangeEvent, useEffect, useState } from "react";

export default function ProductSidebarFilters({
  currentFilters,
}: {
  currentFilters?: any;
}) {
  const [searchVal, setSearchVal] = useState("");
  const [sizeShowMore, setSizeShowMore] = useState(false);
  const [abvShowMore, setAbvShowMore] = useState(false);

  useEffect(() => {
    setSearchVal("");
  }, [currentFilters]);

  const filterOptions = [
    {
      label: "Search Lorem ipsum",

      search: true,
    },
    {
      label: "Category",

      conditionalEvent: 'item.label == "Kegs"',
    },
  ];

  const categorySortRanking: any = {
    "Domestic Specialty": 1,
    Import: 2,
    Premium: 3,
    Value: 4,
    "Ontario Craft": 5,
    "Non Alcoholic": 6,
    International: 7,
    Flavoured: 8,
    "Ready to Drink": 9,
  };

  const filterSorting = (items: any, type: string): Array<any> => {
    switch (type) {
      case "number":
        return items.sort((a: any, b: any) =>
          a.isRefined === b.isRefined ? a.value - b.value : a.isRefined ? -1 : 1
        );
      case "customCategory":
        return items.sort((a: any, b: any) =>
          a.isRefined === b.isRefined
            ? categorySortRanking[a.value] - categorySortRanking[b.value]
            : a.isRefined
            ? -1
            : !a.isRefined && !b.isRefined
            ? categorySortRanking[a.value] - categorySortRanking[b.value]
            : 1
        );
        return items;

      default:
        return [];
    }
  };

  const handleItemChange = (expandedItemLabel: string) => {};
  return (
    <>
      <Accordion
        type="single"
        onValueChange={handleItemChange}
        collapsible
        className="w-full"
        defaultValue={filterOptions[0].label}
      >
        <>
          {filterOptions.map((filterOption: any, _idx: number) => (
            <AccordionItem
              value={filterOption?.label}
              className="border-b-[1px] first:border-t-[1px] border-solid border-[#e2e2e2] py-1"
              key={`aboutus_item${filterOption?.label}`}
            >
              <AccordionTrigger className="AccordionTrigger tracking-[0.25px] text-left hover:no-underline text-[14px] font-sans w-full font-bold flex">
                {filterOption?.label}
              </AccordionTrigger>

              <AccordionContent>
                <div className="pt-[20px]">
                  {filterOption?.search && (
                    <Input
                      aria-label="Search Brand"
                      type="text"
                      placeholder="Search..."
                      endIcon={
                        <Button className="p-[1px] m-0 bg-[transparent] border-0 h-auto w-auto">
                          <span className="icon-search text-[14px] xs:text-[24px] hover:opacity-50"></span>
                        </Button>
                      }
                      value={searchVal}
                      onChange={filterOption.searchOnChange}
                      onKeyDown={(event) => {
                        if (event.key == "Enter" && searchVal.length > 0) {
                          const item =
                            Array.isArray(filterOption?.items) &&
                            filterOption?.items?.length > 0 &&
                            filterOption.items[0];
                          if (item) {
                            filterOption.refine(item.value);
                          }
                        }
                      }}
                      disabled={
                        filterOption?.items?.length < 1 &&
                        !filterOption?.isFromSearch
                      }
                      className="rounded-[50px] h-[50px] border-[#d6d6d6] text-[#4A4F55] text-[14px] px-0 py-[8px] mb-[20px] !pr-[55px] [&_input]:pr-[0]"
                    />
                  )}
                  <div
                    className={`${
                      filterOption?.isShowingMore ||
                      (filterOption.isCustomShowMore &&
                        filterOption?.customShowMore)
                        ? "overflow-auto max-h-[300px] scroll-bar-grey"
                        : ""
                    } mb-[10px]`}
                  >
                    <ul className="">
                      <>
                        {[
                          {
                            isRefined: true,
                            value: true,
                            label: "Retail Opportunities",
                          },
                          {
                            isRefined: false,
                            value: true,
                            label: "External Advertising Campaign",
                          },
                          {
                            isRefined: true,
                            value: true,
                            label: "Planning Tools",
                          },
                        ].map((item: any, idx: any) => (
                          <li
                            key={item.label}
                            data-active={item.isRefined}
                            className="flex  items-start  font-sans font-normal mb-[10px] text-[#4A4F55] text-[14px] hover:text-[#B95804]"
                          >
                            <Checkbox
                              id={`beer_filter${item.label}`}
                              checked={item?.isRefined}
                              className=" w-[18px] h-[18px] bg-white rounded-[5px] border-[#d6d6d6] mr-[5px] 2xs:mr-[10px] [&[data-state='checked']]:bg-black [&[data-state='checked']]:border-black [&[data-state='checked']]:text-white [&>[data-state='checked']>svg]:h-[10px]  [&>[data-state='checked']>svg]:w-[10px] [&>[data-state='checked']>svg]:stroke-[4px]"
                            />
                            <span className="cursor-pointer flex justify-center text-[10px] 3xs:text-[12px] 2xs:text-[14px]">
                              {["true", "false"].includes(item.value)
                                ? item.value == "true"
                                  ? filterOption.label
                                  : "Non" + filterOption.label
                                : item.label}{" "}
                              {/* <span className="ml-[5px] min-w-[25px] inline-flex items-center pt-[5px] pb-[4px] h-[18px] px-1.5 justify-center text-[10px] font-bold leading-none border border-[#d6d6d6] text-[#4B4F54] bg-[#f4f4f4] rounded-full">
                                  {item?.count}
                                </span> */}
                            </span>
                          </li>
                        ))}
                      </>

                      {/* : (
                        <li className="flex items-start lg:items-center font-sans font-normal mb-[10px] text-[#4A4F55] text-[14px]">
                          <span> No Results</span>
                        </li>
                      ) */}
                    </ul>
                  </div>
                  <div>
                    {(filterOption?.canToggleShowMore ||
                      (filterOption?.isCustomShowMore &&
                        filterOption.items.length > 9)) && (
                      <Button
                        variant={"link"}
                        className="p-0 mb-[10px] h-auto text-[#D06F1A] hover:underline"
                        onClick={() =>
                          filterOption?.isCustomShowMore
                            ? filterOption.setCustomShowMore(
                                (prev: any) => !prev
                              )
                            : filterOption?.toggleShowMore()
                        }
                      >
                        {filterOption.isCustomShowMore
                          ? filterOption?.customShowMore
                            ? "Load Less"
                            : "Load More"
                          : filterOption?.isShowingMore
                          ? "Load Less"
                          : "Load More"}
                      </Button>
                    )}
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </>
      </Accordion>
    </>
  );
}
