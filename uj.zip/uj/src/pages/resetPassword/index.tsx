"use client";
import React, { useState } from "react";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Button } from "../../components/ui/button";
import { useForm } from "react-hook-form";
import { Input } from "../../components/ui/input";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Alert, AlertDescription, AlertTitle } from "../../components/ui/alert";
import { resetPasswordSchema } from "../../lib/validationSchema/validation";
import Layout from "../layout/layout";
import HidePass from "../../images/login/hide-pass.svg";
import ShowPass from "../../images/login/show-pass.svg";
export default function ResetPassword() {
  const form = useForm<z.infer<typeof resetPasswordSchema>>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
    mode: "onChange",
  });

  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] =
    useState<boolean>(false);
  const [resettingPassword, setResettingPassword] = useState<boolean>(false);
  const [error, setErrror] = useState<boolean>(false);
  const [responseStatus, setResponseStatus] = useState<string>("");

  const onSubmit = async (data: any) => {};
  return (
    <Layout>
      <div className="flex justify-center w-full items-center container py-[80px]">
        <div
          className={`max-w-[455px] w-full flex flex-col justify-center min-h-[613px]`}
        >
          {error && (
            <Alert variant="alert" className="mb-[30px]">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Oops! Something went wron g. Please try again.
              </AlertDescription>
            </Alert>
          )}
          {responseStatus !== "" && (
            <Alert variant="alert" className="mb-[30px]">
              <AlertDescription>{responseStatus}</AlertDescription>
            </Alert>
          )}
          <h1
            className={`mb-[24px] leading-[1.2] text-center text-[32px] xs:mb-5  font-sans font-bold text-[#000] md:text-[40px] `}
          >
            Reset Password
          </h1>

          <p className="mb-[15px] xs:mb-[40px] text-center">
            Please enter a new password:
          </p>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="max-w-[700px] [&_.reply-input>input]:text-[#4A4F55] [&_.reply-input>input]:placeholder:text-[14px]  flex flex-col [&_.error-msg]:text-[12px] [&_.error-msg]:text-[#bf1332] [&_.error-msg]:leading-5 [&_.error-msg]:font-sans [&_.form-label]:text-[14px] [&_.form-label]:font-normal [&_.form-label]:font-sans [&_.form-label]:leading-5 [&_.form-itm]:mb-5 [&_.form-checkbox]:my-[10px]"
            >
              <div className="flex flex-col">
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem className="form-itm">
                      <FormLabel className="form-label">
                        New Password
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <Input
                        maxLength={16}
                        type={showPassword ? "text" : "password"}
                        className={`reply-input ${
                          form.formState.errors.password
                            ? "border-[#bf1332]"
                            : "border-[#d6d6d6]"
                        }`}
                        placeholder="Enter New Password"
                        {...field}
                        endIcon={
                          <img
                            tabIndex={0}
                            onClick={() => setShowPassword((prev) => !prev)}
                            onKeyDown={(event) => {
                              if (event.key === "Enter") {
                                setShowPassword((prev) => !prev);
                              }
                            }}
                            src={showPassword ? ShowPass : HidePass}
                            height={16}
                            width={16}
                            alt="eye"
                            className="cursor-pointer eyeicon"
                          />
                        }
                        onFocus={() => {
                          setErrror(false);
                          setResponseStatus("");
                        }}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem className="form-itm">
                      <FormLabel className="form-label">
                        Re-enter New Password
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <Input
                        maxLength={16}
                        type={showConfirmPassword ? "text" : "password"}
                        className={`reply-input ${
                          form.formState.errors.confirmPassword
                            ? "border-[#bf1332]"
                            : "border-[#d6d6d6]"
                        }`}
                        placeholder="Re-enter New Password"
                        {...field}
                        endIcon={
                          <img
                            tabIndex={0}
                            onClick={() =>
                              setShowConfirmPassword((prev) => !prev)
                            }
                            onKeyDown={(event) => {
                              if (event.key === "Enter") {
                                setShowConfirmPassword((prev) => !prev);
                              }
                            }}
                          src={showPassword ? ShowPass : HidePass }
                            height={16}
                            width={16}
                            alt="eye"
                            className="cursor-pointer eyeicon"
                          />
                        }
                        onFocus={() => {
                          setErrror(false);
                          setResponseStatus("");
                        }}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />
              </div>
              <Button
                type="submit"
                className=" uppercase h-[50px]  text-[16px] font-sans font-bold leading-5 mt-5 rounded-[200px] px-[30px] py-[15px] "
              >
                {resettingPassword ? "Reset Password..." : "Reset Password"}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </Layout>
  );
}
