import React from "react";
import { Button } from "../../components/ui/button";
import { useNavigate } from "react-router-dom";
import NotFoundIcon from "../../images/notfound/notfound-text.svg";
export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="centered">
      <div
        id="start-of-content"
        role="complementary"
        aria-label="Main content Begins Here"
      >
        <label className="hidden">Content Starts Here </label>
      </div>
      <div className="text-center py-[48px] px-[25px] md:w-[600px] md:py-[80px] m-auto">
        <img
          src={NotFoundIcon}
          alt="Not found"
          width={286}
          height={129}
          className="inline-block m-auto"
        />
        <h2 className="text-[32px] font-sans mt-[26px] mb-[20px]">
          Its not you, its us!
        </h2>
        <p className="leading-[24px] mb-[16px]">{`We just can’t find the page you’re looking for. Go crack a beer, we’ll fix it soon. Why don’t you grab a cold one and visit the home page to check out our selection of 1,000+ brand of beer`}</p>
        <Button
          className="rounded-full inline-block text-[16px] h-auto font-sans font-bold pt-[13px] pb-[11px] px-[30px] uppercase"
          onClick={() => navigate("/")}
        >
          Back to Home
        </Button>
      </div>
    </div>
  );
}
