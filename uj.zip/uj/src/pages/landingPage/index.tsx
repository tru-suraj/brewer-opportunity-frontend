import React from "react";
import Layout from "../layout/layout";
import { Link, useNavigate } from "react-router-dom";
import BannerOne from "../../images/banner/banner_img_one.avif";
import BannerTwo from "../../images/banner/banner_img_two.avif";
import BannerThree from "../../images/banner/banner_img_three.avif";
import BannerFour from "../../images/banner/banner_img_four.jpg";
import BannerOneMob from "../../images/banner/banner_img_mob_one.avif";
import BannerTwoMob from "../../images/banner/banner_img_mob_two.avif";
import BannerThreeMob from "../../images/banner/banner_img_mob_three.avif";
import BannerFourMob from "../../images/banner/banner_img_mob_four.avif";
import BannerFooter from "../../images/bannerFotter.png";
import Dummy from "../../images/dummy.png";
import InfoCard from "../../components/infoCard";
import { Button } from "../../components/ui/button";

export default function Home() {
  const navigate = useNavigate();
  let bannerdata: any = [];
  function handleDataLayerOnImageClick(internalName: any, arg1: number): void {
    throw new Error("Function not implemented.");
  }
  let data = [1, 2, 3, 4];
  return (
    <Layout>
      {/* banner */}
      <section className="max-w-[1920px] mx-auto  homeImgTabBorderWrapper">
        <div className="flex md:flex-row gap-[10px] flex-col">
          <div className="w-100 md:w-1/2">
            <Link
              className="relative"
              onClick={() =>
                handleDataLayerOnImageClick(
                  bannerdata?.[0]?.cardMedia?.internalName,
                  1
                )
              }
              to={
                bannerdata[0]?.cardButtonCollection?.items?.[0]?.redirectUrl ||
                "#"
              }
              target={
                bannerdata[0]?.cardButtonCollection?.items?.[0]?.buttonTarget
              }
              aria-label={
                bannerdata[0]?.cardButtonCollection?.items?.[0]?.buttonAriaLabel
              }
            >
              <img
                alt={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.title}
                src={BannerOneMob}
                aria-label={
                  bannerdata?.[0]?.cardMedia?.thumbnailDesktopAriaLabel
                }
                width={bannerdata?.[0]?.cardMedia?.thumbnailMobile?.width}
                height={bannerdata?.[0]?.cardMedia?.thumbnailMobile?.height}
                className="w-full block md:hidden"
              />
              {/* {bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.url && (
                <img
                  alt={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.title}
                  src={bannerdata?.[0]?.cardMedia?.thumbnailMobile?.url}
                  aria-label={
                    bannerdata?.[0]?.cardMedia?.thumbnailDesktopAriaLabel
                  }
                  width={bannerdata?.[0]?.cardMedia?.thumbnailMobile?.width}
                  height={bannerdata?.[0]?.cardMedia?.thumbnailMobile?.height}
                  className="w-full block md:hidden"
                />
              )} */}
              <img
                alt={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.title}
                src={BannerOne}
                aria-label={
                  bannerdata?.[0]?.cardMedia?.thumbnailDesktopAriaLabel
                }
                width={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.width}
                height={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.height}
                className="w-full hidden md:block"
              />
              {/* {bannerdata?.[0]?.cardMedia?.thumbnailMobile?.url && (
                <img
                  alt={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.title}
                  src={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.url}
                  aria-label={
                    bannerdata?.[0]?.cardMedia?.thumbnailDesktopAriaLabel
                  }
                  width={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.width}
                  height={bannerdata?.[0]?.cardMedia?.thumbnailDesktop?.height}
                  className="w-full hidden md:block"
                />
              )} */}
            </Link>
          </div>
          <div className="w-100 md:w-1/2 flex flex-col gap-[10px] md:gap-[6px] lg:gap-[7px] xl-1536:gap-[9px]">
            <div>
              <Link
                className="relative"
                onClick={() =>
                  handleDataLayerOnImageClick(
                    bannerdata?.[1]?.cardMedia?.internalName,
                    2
                  )
                }
                to={
                  bannerdata[1]?.cardButtonCollection?.items?.[0]
                    ?.redirectUrl || "#"
                }
                target={
                  bannerdata[1]?.cardButtonCollection?.items?.[0]?.buttonTarget
                }
                aria-label={
                  bannerdata[1]?.cardButtonCollection?.items?.[0]
                    ?.buttonAriaLabel
                }
              >
                <img
                  alt={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.title}
                  src={BannerTwoMob}
                  aria-label={
                    bannerdata?.[1]?.cardMedia?.thumbnailDesktopAriaLabel
                  }
                  width={bannerdata?.[1]?.cardMedia?.thumbnailMobile?.width}
                  height={bannerdata?.[1]?.cardMedia?.thumbnailMobile?.height}
                  className="w-full block md:hidden"
                />
                {/* {bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.url && (
                  <img
                    alt={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.title}
                    src={bannerdata?.[1]?.cardMedia?.thumbnailMobile?.url}
                    aria-label={
                      bannerdata?.[1]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[1]?.cardMedia?.thumbnailMobile?.width}
                    height={bannerdata?.[1]?.cardMedia?.thumbnailMobile?.height}
                    className="w-full block md:hidden"
                  />
                )} */}
                <img
                  alt={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.title}
                  src={BannerTwo}
                  aria-label={
                    bannerdata?.[1]?.cardMedia?.thumbnailDesktopAriaLabel
                  }
                  width={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.width}
                  height={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.height}
                  className="w-full hidden md:block"
                />
                {/* {bannerdata?.[1]?.cardMedia?.thumbnailMobile?.url && (
                  <img
                    alt={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.title}
                    src={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.url}
                    aria-label={
                      bannerdata?.[1]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.width}
                    height={
                      bannerdata?.[1]?.cardMedia?.thumbnailDesktop?.height
                    }
                    className="w-full hidden md:block"
                  />
                )} */}
              </Link>
            </div>
            <div className="flex sm:flex-row gap-[10px]">
              <div className="w-1/2">
                <Link
                  className="relative"
                  onClick={() =>
                    handleDataLayerOnImageClick(
                      bannerdata?.[2]?.cardMedia?.internalName,
                      3
                    )
                  }
                  to={
                    bannerdata[2]?.cardButtonCollection?.items?.[0]
                      ?.redirectUrl || "#"
                  }
                  target={
                    bannerdata[2]?.cardButtonCollection?.items?.[0]
                      ?.buttonTarget
                  }
                  aria-label={
                    bannerdata[2]?.cardButtonCollection?.items?.[0]
                      ?.buttonAriaLabel
                  }
                >
                  <img
                    alt={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.title}
                    src={BannerThreeMob}
                    aria-label={
                      bannerdata?.[2]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[2]?.cardMedia?.thumbnailMobile?.width}
                    height={bannerdata?.[2]?.cardMedia?.thumbnailMobile?.height}
                    className="w-full block md:hidden"
                  />
                  {/* {bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.url && (
                    <img
                      alt={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.title}
                      src={bannerdata?.[2]?.cardMedia?.thumbnailMobile?.url}
                      aria-label={
                        bannerdata?.[2]?.cardMedia?.thumbnailDesktopAriaLabel
                      }
                      width={bannerdata?.[2]?.cardMedia?.thumbnailMobile?.width}
                      height={
                        bannerdata?.[2]?.cardMedia?.thumbnailMobile?.height
                      }
                      className="w-full block md:hidden"
                    />
                  )} */}
                  <img
                    alt={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.title}
                    src={BannerThree}
                    aria-label={
                      bannerdata?.[2]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.width}
                    height={
                      bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.height
                    }
                    className="w-full hidden md:block"
                  />
                  {/* {bannerdata?.[2]?.cardMedia?.thumbnailMobile?.url && (
                    <img
                      alt={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.title}
                      src={bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.url}
                      aria-label={
                        bannerdata?.[2]?.cardMedia?.thumbnailDesktopAriaLabel
                      }
                      width={
                        bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.width
                      }
                      height={
                        bannerdata?.[2]?.cardMedia?.thumbnailDesktop?.height
                      }
                      className="w-full hidden md:block"
                    />
                  )} */}
                </Link>
              </div>
              <div className="w-1/2">
                <Link
                  className="relative"
                  onClick={() =>
                    handleDataLayerOnImageClick(
                      bannerdata?.[3]?.cardMedia?.internalName,
                      4
                    )
                  }
                  to={
                    bannerdata[3]?.cardButtonCollection?.items?.[0]
                      ?.redirectUrl || "#"
                  }
                  target={
                    bannerdata[3]?.cardButtonCollection?.items?.[0]
                      ?.buttonTarget
                  }
                  aria-label={
                    bannerdata[3]?.cardButtonCollection?.items?.[0]
                      ?.buttonAriaLabel
                  }
                >
                  <img
                    alt={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.title}
                    src={BannerFourMob}
                    aria-label={
                      bannerdata?.[3]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[3]?.cardMedia?.thumbnailMobile?.width}
                    height={bannerdata?.[3]?.cardMedia?.thumbnailMobile?.height}
                    className="w-full block md:hidden"
                  />
                  {/* {bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.url && (
                    <img
                      alt={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.title}
                      src={bannerdata?.[3]?.cardMedia?.thumbnailMobile?.url}
                      aria-label={
                        bannerdata?.[3]?.cardMedia?.thumbnailDesktopAriaLabel
                      }
                      width={bannerdata?.[3]?.cardMedia?.thumbnailMobile?.width}
                      height={
                        bannerdata?.[3]?.cardMedia?.thumbnailMobile?.height
                      }
                      className="w-full block md:hidden"
                    />
                  )} */}
                  <img
                    alt={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.title}
                    src={BannerFour}
                    aria-label={
                      bannerdata?.[3]?.cardMedia?.thumbnailDesktopAriaLabel
                    }
                    width={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.width}
                    height={
                      bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.height
                    }
                    className="w-full hidden md:block"
                  />
                  {/* {bannerdata?.[3]?.cardMedia?.thumbnailMobile?.url && (
                    <img
                      alt={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.title}
                      src={bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.url}
                      aria-label={
                        bannerdata?.[3]?.cardMedia?.thumbnailDesktopAriaLabel
                      }
                      width={
                        bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.width
                      }
                      height={
                        bannerdata?.[3]?.cardMedia?.thumbnailDesktop?.height
                      }
                      className="w-full hidden md:block"
                    />
                  )} */}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* banner end here*/}
      {/* opportuinty highlights */}
      <section className="px-[45px] container py-[80px] min-h-[674px]">
        <div className="flex flex-col gap-[60px]">
          <div className={"flex flex-col"}>
            <h2 className="text-[20px] font-GothamMedium 3sx:text-[24px] xs:text-[32px] md:text-[28px] lg:text-[40px] xl:text-[48px]  leading-[25px] 3xs:leading-[30px] xs:leading-[42px] md:leading-[30px] lg:leading-[45px] xl:leading-[50px] text-[#000] m-0 flex items-center mb-5">
              {"Program highlights"}
            </h2>
            <p className="font-sans text-[14px]">
              Where featuring an innovation, a limited time offer or incentive,
              or building your brand, The Beer Store has a program to amplify
              your brand purpose.
            </p>
          </div>
          <div className="flex felx-row gap-[30px]">
            {data.map((itm) => (
              <div key={itm} className="basis-full md:basis-1/4">
                <div className="main-info md:py-0">
                  <InfoCard
                    badgeText="Digital"
                    from="home"
                    title={"Bolton Exclusive Programs"}
                    description={
                      "Ut enim ad minim veniam, quis nostrud exerci tation ullamco laboris nisi ut aliquip ex ea commodo consequat"
                    }
                    image={{
                      url: Dummy,
                      alt: "dummy",
                      width: 355,
                      height: 232,
                    }}
                    className={`equal-h flex-col flex shadow-none rounded-[10px] border-[1px] overflow-hidden [&_.info-content]:py-[20px] md:[&_.info-content]:!p-5  [&_.info-content]:!px-0 [&_.info-content>div>h2]:mb-[20px] [&_.info-content>div>h2]:!leading-[24px] md:[&_.info-content>div>h2]:!leading-[30px] [&_.info-content>]:.eq-height [&>div>div>a]:font-bold [&>div>div>a]:uppercase [&>div>img]:rounded-[10px] [&_.info-content>div>h2]:text-[16px] md:[&_.info-content>div>h2]:text-[20px] [&_.info-content>div>h2]:font-medium md:[&_.info-content>div>h2]:font-bold 
                      [&_.info-header]:relative
                      [&_.info-header]:overflow-hidden
                      [&_.info-header]:pt-[68%]
                      [&_.info-header]:rounded-[10px]
                      [&>div>img]:absolute [&>div>img]:top-0 [&>div>img]:left-0 [&>div>img]:object-contain
                      [&_.info-title]:max-w-full 3xs:[&_.info-title]:max-w-[250px] 3xs:[&_.info-title]:max-w-[250px] md:[&_.info-title]:max-w-full info-height [&_.info-footer]:p-[2px] [&_button]:!w-auto`}
                    buttonLink={`/`}
                    buttonText={"Learn More"}
                    buttonAriaLabel={"Learn More"}
                    index={itm + 1}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Button
              variant={"secondary"}
              className="uppercase rounded-[30px]"
              onClick={() => navigate("/programs")}
            >
              View all
            </Button>
          </div>
        </div>
      </section>
      {/* opportuinty highlights end here */}
      {/* previosSubmissionForm */}
      <section className="px-[45px] container py-[80px] min-h-[674px]">
        <div className="flex flex-row items-center gap-[30px]">
          <div className={"flex flex-col  basis-1/2 gap-[30px] center"}>
            <h2 className="text-[20px]  3sx:text-[24px] xs:text-[32px] md:text-[28px] lg:text-[40px] xl:text-[48px] font-GothamMedium leading-[25px] 3xs:leading-[30px] xs:leading-[42px] md:leading-[30px] lg:leading-[45px] xl:leading-[50px] text-[#000] m-0 flex items-center mb-5">
              {"Continue Your Previous Submission"}
            </h2>
            <p className="font-sans text-[14px]">
              Where featuring an innovation, a limited time offer or incentive,
              or building your brand, The Beer Store has a program to amplify
              your brand purpose.
            </p>
            <div>
              <Button className="uppercase rounded-[30px] w-auto">
                Continue Progress
              </Button>
            </div>
          </div>
          <div className="basis-1/2">
            <img
              src={require("../../images/split.png")}
              alt={"login"}
              className="h-full object-cover"
            />
          </div>
        </div>
      </section>
      {/* previosSubmissionForm end here*/}
      {/* Features */}
      <section className="bg-[#F4F4F4]">
        <div className="px-[45px] container py-[80px] min-h-[674px] ">
          <div className="flex flex-col gap-[60px]">
            <div className={"flex flex-col"}>
              <h2 className="text-[20px]  3sx:text-[24px] xs:text-[32px] md:text-[28px] lg:text-[40px] xl:text-[48px] font-GothamMedium leading-[25px] 3xs:leading-[30px] xs:leading-[42px] md:leading-[30px] lg:leading-[45px] xl:leading-[50px] text-[#000] m-0 flex items-center mb-5">
                {"Don't Miss Out"}
              </h2>
              <p className="font-sans text-[14px]">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>
            <div className="flex felx-row gap-[30px]">
              {data.slice(0, 3).map((itm) => (
                <div key={itm} className="basis-full md:basis-1/3">
                  <div className="main-info md:py-0">
                    <InfoCard
                      badgeText="Featured"
                      from="home"
                      title={"Bolton Exclusive Programs"}
                      description={
                        "Ut enim ad minim veniam, quis nostrud exerci tation ullamco laboris nisi ut aliquip ex ea commodo consequat"
                      }
                      image={{
                        url: Dummy,
                        alt: "dummy",
                        width: 355,
                        height: 232,
                      }}
                      className={`equal-h flex-col flex shadow-none rounded-[10px] border-[1px] overflow-hidden [&_.info-content]:py-[20px] md:[&_.info-content]:!p-5  [&_.info-content]:!px-0 [&_.info-content>div>h2]:mb-[20px] [&_.info-content>div>h2]:!leading-[24px] md:[&_.info-content>div>h2]:!leading-[30px] [&_.info-content>]:.eq-height [&>div>div>a]:font-bold [&>div>div>a]:uppercase [&>div>img]:rounded-[10px] [&_.info-content>div>h2]:text-[16px] md:[&_.info-content>div>h2]:text-[20px] [&_.info-content>div>h2]:font-medium md:[&_.info-content>div>h2]:font-bold 
                      [&_.info-header]:relative
                      [&_.info-header]:overflow-hidden
                      [&_.info-header]:pt-[68%]
                      [&_.info-header]:rounded-[10px]
                      [&>div>img]:absolute [&>div>img]:top-0 [&>div>img]:left-0 [&>div>img]:object-contain
                      [&_.info-title]:max-w-full 3xs:[&_.info-title]:max-w-[250px] 3xs:[&_.info-title]:max-w-[250px] md:[&_.info-title]:max-w-full info-height [&_.info-footer]:p-[2px] [&_button]:!w-auto bg-white `}
                      buttonLink={`/`}
                      buttonText={"Applay now"}
                      buttonAriaLabel={"Applay now"}
                      index={itm + 1}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      {/* Features end here */}
      {/* FooterBaner */}
      <section className="max-w-[1920px] mx-auto relative  homeImgTabBorderWrapper">
        <div className="">
          <img src={BannerFooter} alt="BannerFooter" />
        </div>
        <div className="max-w-[644px] centered">
          <div className="flex flex-col  items-center gap-5 ">
            <h2 className="text-[48px] text-center text-[#fff] leading-[60px] font-GothamMedium">
              Promotional & Advertising Opportunities
            </h2>
            <div>
              <Button
                className="rounded-[30px] uppercase font-GothamMedium"
                onClick={() => navigate("/contactUs")}
              >
                Contact us
              </Button>
            </div>
          </div>
        </div>
      </section>
      {/* FooterBaner end here */}
    </Layout>
  );
}
