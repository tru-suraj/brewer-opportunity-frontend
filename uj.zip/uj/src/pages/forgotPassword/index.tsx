import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import { Button } from "../../components/ui/button";
import * as z from "zod";
import { useCallback, useEffect, useState } from "react";
import { Alert, AlertDescription } from "../../components/ui/alert";
import Layout from "../layout/layout";
import { Link, useNavigate } from "react-router-dom";

const formSchema = z.object({
  email: z
    .string()
    .min(1, {
      message: "This field is required.",
    })
    .email("Please enter a valid email address."),
});

export default function ForgotPassword({ res = "" }) {
  const navigate = useNavigate();
  const [isSendingRequest, setIsSendingRequest] = useState(false);
  const [sentRequest, setSentRequest] = useState("");
  const [error, setError] = useState("");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
    },
    mode: "onChange",
  });

  const onSubmit = (data: any) => {
    navigate("/resetPassword");
  };

  useEffect(() => {
    // if (userCookie && userCookie.hasOwnProperty("id")) {
    //   router.push("/");
    // }
    // if (res) {
    //   setError(`The key is no longer valid. Please reset your password again.`);
    // }
  }, []);

  return (
    <Layout>
      <div className="flex justify-center w-full items-center container py-[80px]">
        <div
          className={`max-w-[455px] w-full flex flex-col justify-center min-h-[613px]`}
        >
          {error && (
            <Alert variant="destructive" className="mb-[20px] bg">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {sentRequest && (
            <Alert
              variant="default"
              className="mb-[20px] bg-[#F4B233] border-[#F4B233] text-black"
            >
              <AlertDescription>{sentRequest}</AlertDescription>
            </Alert>
          )}
          <h1
            className={`mb-[24px] leading-[1.2] text-center text-[32px] xs:mb-5  font-sans font-bold text-[#000] md:text-[40px] `}
          >
            Forgot Password
          </h1>

          <p className="mb-[15px] xs:mb-[40px] text-center">
            Please enter your email address below
            <br />
            to reset your password:
          </p>
          <Form {...form}>
            <form
              onSubmit={form.handleSubmit(onSubmit)}
              className="[&_.form-label]:text-[14px] [&_.reply-input>input]:text-[#4A4F55] [&_.reply-input>input]:placeholder:text-[14px] [&_.form-label]:font-normal [&_.form-label]:font-sans [&_.form-label]:leading-5 [&_.form-itm]:mb-8"
            >
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="form-itm">
                    <FormLabel
                      htmlFor="email"
                      className="form-label text-[#4A4F55]"
                    >
                      Email Address
                      <sup className="text-[#AD2F33] text-[14px] align-text-bottom">
                        *
                      </sup>
                    </FormLabel>
                    <Input
                      id="email"
                      className={`reply-input ${
                        form.formState.errors.email
                          ? "border-[#bf1332]"
                          : "border-[#d6d6d6]"
                      } text-[#4A4F55]`}
                      placeholder="Enter Email Address"
                      {...field}
                      onChange={(event) => {
                        const cleanedValue = event.target.value
                          .replace("+", "")
                          .trim();
                        field.onChange(cleanedValue);
                      }}
                      onFocus={() => setError("")}
                    />
                    <FormMessage className="text-[#bf1332] text-[12px] align-text-bottom" />
                  </FormItem>
                )}
              />

              <div>
                <Button
                  type="submit"
                  className={`w-full h-[50px] uppercase  font-sans font-bold text-[16px] leading-[1.2] rounded-[25px] mb-[30px]`}
                >
                  {isSendingRequest ? "Please Wait..." : "Reset Password"}
                </Button>
                <div className="text-center ">
                  <Link
                    to={"/login"}
                    className="text-[#D06F1A] text-[14px] leading-[20px]  font-sans font-bold hover:underline"
                  >
                    Back to Sign in
                  </Link>
                </div>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </Layout>
  );
}
