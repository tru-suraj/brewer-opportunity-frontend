import Header from "../header";
import Fotter from "../footer";

export default function layout({ children }: { children?: React.ReactNode }) {
  return (
    <>
      <Header />
      <div className="overflow-y-auto">{children}</div>
      <Fotter />
    </>
  );
}
