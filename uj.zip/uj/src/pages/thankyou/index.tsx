import React from "react";
import ThankYou from "../../components/ui/thankYou";
import Layout from "../layout/layout";

type Props = {};

export default function ThankYouMessage({}: Props) {
  return (
    <Layout>
      <section className="container py-[80px] ">
        <ThankYou className="min-h-[613px]  " />;
      </section>
    </Layout>
  );
}
