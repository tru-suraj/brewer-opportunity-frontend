import { useState } from "react";
import { FullPageTemplate } from "../../Modules/programsLayout/fullPageTemplate";
import { useMediaQuery } from "../../hooks/useMediaQuery";
import { SidebarLayout } from "../../Modules/programsLayout";
import { Button } from "../../components/ui/button";
import CloseSvg from "../../images/sidebarclose.svg";
import Filter from "../../images/filters.svg";
import InfoCard from "../../components/infoCard";
import Dummy from "../../images/dummy.png";
import Program from "../../images/programbg.jpg";
import ProductSidebarFilters from "../../Modules/sidebarFilters";
import {useNavigate } from "react-router-dom";

export default function Programs() {
  const navigate = useNavigate();
  const [showSidebarFilters, setShowSidebarFilters] = useState(false);
  const mediaScreen = useMediaQuery({ "max-width": "767.98px" });

  const showSidebarStyle = "left-0 visible delay-600 duration-700 z-[1020]";
  const fixedlayoutStyle =
    "fixed bg-white right-0 bottom-0 top-0 w-full h-full overflow-auto invisible";
  const ToggleSidebarLayout = () => {
    setShowSidebarFilters(true);
  };
  return (
    <FullPageTemplate
      desktopBg={Program}
      bannerTitle={"Advertising & Promotional Opportunities Brewer Portal"}
    >
      {/* {!isLoading &&
    searchQuery &&
    searchQuery?.length > 0 &&
    products.length < 1 && !filters &&
    currentRefinements.length < 1 ? (
      <NoSearchResult searchQuery={searchQuery} />
    ) : ( */}
      <>
        <div className="flex flex-col md:flex-row relative pb-[30px] xs:pb-[48px] md:pb-[50px] lg:pb-[60p] xxl:pb-[70px] 2xl:pb-[80px]">
          <div
            style={{
              ...(showSidebarFilters && {
                visibility: showSidebarFilters ? "visible" : "hidden",
              }),
            }}
            className={`
           ${mediaScreen && fixedlayoutStyle}
            md:h-auto
            py-[30px]
            px-[24px]
            md:p-0
            md:left-0
            md:relative
            md:transition-none
            md:visible
            flex-1
            md:z-auto
            md:basis-2/6
            lg:basis-1/4
            ${showSidebarFilters && showSidebarStyle} 
            ${
              !showSidebarFilters &&
              mediaScreen &&
              "left-full z-[-1] delay-600 duration-700 "
            }
           `}
          >
            {mediaScreen && (
              <div
                className="absolute justify-end right-[24px] top-[30px] flex cursor-pointer"
                onClick={() => setShowSidebarFilters(false)}
              >
                <img src={CloseSvg} width={20} height={26} alt="close" />
              </div>
            )}

            <SidebarLayout bordered={false}>
              <div className="mb-5">
                <h2 className="text-[18px] text-left  leading-[28px] font-GothamBold">
                  FILTERS
                </h2>
              </div>
              <div className="px-0 pb-[30px] md:pr-[23px] md:pb-[25px] md:pl-0">
                <ProductSidebarFilters />
              </div>
            </SidebarLayout>
          </div>
          <div className="basis-full md:basis-4/6 lg:basis-3/4">
            <div className="flex flex-col px-0 md:pl-[7px] ">
              {/* {searchQuery?.length > 0 && (
                <div className="flex">
                  <Alert className="bg-[#f4f4f4] rounded-[10px] mb-[40px] p-[18px] border-none">
                    <AlertDescription className="text-[#4A4F55] text-center leading-[1]">
                      Showing results for:{" "}
                      <span className="uppercase font-bold">
                        &ldquo;{searchQuery}&rdquo;{" "}
                      </span>
                    </AlertDescription>
                  </Alert>
                </div>
              )} */}
              {/* {mediaScreen && (
                <div className="flex justify-between my-[10px]">
                  <AlgoliaStats />
                  
                </div>
              )} */}
              <div className="flex flex-row mb-[30px] justify-between items-center beers-filter">
                {/* <div className="hidden md:flex">
                  <AlgoliaStats />
                </div> */}
                {mediaScreen && (
                  <Button
                    onClick={ToggleSidebarLayout}
                    variant="outline"
                    className="border-[1px] border-[#D6D6D6] rounded-full h-[40px] w-[40px] p-[0] ml-auto xs:h-[50px] xs:w-[50px]"
                  >
                    <img
                      src={Filter}
                      alt="filter"
                      width={14}
                      height={14}
                      className={"mr-[0px]"}
                    />
                    {/* Filters */}
                  </Button>
                )}
                {/* {!results.__isArtificial && results.nbHits === 0 ? null : (
                  <div className="items-center flex flex-col xs:flex-row max-w-[calc(95px-5px)] 3xs:max-w-[calc(120px-5px)] xs:max-w-[calc(190px-10px)] ml-[5px] xs:ml-[10px] md:ml-[0]  md:max-w-[260px] gap-[10px] xs:gap-0">
                    <span className="hidden md:inline-block text-black text-[14px] mr-0 xs:mr-[15px] text-left w-[70px]">
                      Sort by
                    </span>
                    <SortByRefine
                      items={[
                        { label: "Relevance", value: ALGOLIA_PRODUCT_INDEX },
                        {
                          label: "On Sale",
                          value: ALGOLIA_PRODUCT_SALE_SORTING_INDEX,
                        },
                        {
                          label: "Best Sellers",
                          value: ALGOLIA_BEST_SELLER_SORTING_INDEX,
                        },
                        {
                          label: "New Arrivals",
                          value: ALGOLIA_WHATS_NEW_SORTING_INDEX,
                        },
                        {
                          label: "Product A to Z",
                          value: ALGOLIA_PRODUCT_NAME_ASC_SORTING_INDEX,
                        },
                        {
                          label: "Product Z to A",
                          value: ALGOLIA_PRODUCT_NAME_DESC_SORTING_INDEX,
                        },
                        {
                          label: "Price (Low to High)",
                          value: ALGOLIA_PRODUCT_PRICE_ASC_SORTING_INDEX,
                        },
                        {
                          label: "Price (High to Low)",
                          value: ALGOLIA_PRODUCT_PRICE_DESC_SORTING_INDEX,
                        },
                      ]}
                      isMobile={mediaScreen}
                    />
                  </div>
                )} */}
              </div>
              {/* {isLoading && storeId ? (
                <MugLoader />
              ) : (!results.__isArtificial && results.nbHits === 0) ||
                !storeId ? (
                <NoFilterResults
                  clearFilters={clearRefinementHandler}
                  pageRoute={PLP_PAGE_ROUTE}
                />
              ) : ( */}
              <>
                <div className="main-info grid  grid-cols-1 md:grid-cols-2   xl:grid-cols-3  gap-y-[30px]  gap-x-[20px] md:gap-[30px]">
                  {[1, 2, 3, 4, 5].map((item, idx) => (
                    <div key={item} className="basis-full md:basis-1/3">
                      <div className="main-info md:py-0">
                        <InfoCard
                          onClickButton={() => navigate(`/programs/${idx}`)}
                          badgeText="Digital"
                          from="home"
                          title={"Digital Bundle Packages"}
                          description={
                            "Ut enim ad minim veniam, quis nostrud exerci tation ullamco laboris nisi ut aliquip ex ea commodo consequat"
                          }
                          image={{
                            url: Dummy,
                            alt: "dummy",
                            width: 355,
                            height: 232,
                          }}
                          className={`equal-h flex-col flex shadow-none rounded-[10px] border-[1px] overflow-hidden [&_.info-content]:py-[20px] md:[&_.info-content]:!p-5  [&_.info-content]:!px-0 [&_.info-content>div>h2]:mb-[20px] [&_.info-content>div>h2]:!leading-[24px] md:[&_.info-content>div>h2]:!leading-[30px] [&_.info-content>]:.eq-height [&>div>div>a]:font-bold [&>div>div>a]:uppercase [&>div>img]:rounded-[10px] [&_.info-content>div>h2]:text-[16px] md:[&_.info-content>div>h2]:text-[20px] [&_.info-content>div>h2]:font-medium md:[&_.info-content>div>h2]:font-bold 
                            [&_.info-header]:relative
                            [&_.info-header]:overflow-hidden
                            [&_.info-header]:pt-[68%]
                            [&_.info-header]:rounded-[10px]
                            [&>div>img]:absolute [&>div>img]:top-0 [&>div>img]:left-0 [&>div>img]:object-contain
                            [&_.info-title]:max-w-full 3xs:[&_.info-title]:max-w-[250px] md:[&_.info-title]:max-w-full info-height [&_.info-footer]:p-[2px] [&_button]:!w-auto`}
                          buttonLink={`/programs/${idx}`}
                          buttonText={"Apply Now"}
                          buttonAriaLabel={"Apply Now"}
                          index={item + 1}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </>
              {/* )} */}
              {/* {!isLoading && products.length > 0 && (
                <ProductPagination {...pagination} />
              )} */}
            </div>
          </div>
        </div>
      </>
      {/* )} */}
    </FullPageTemplate>
  );
}
