import { useForm } from "react-hook-form";
import { FullPageTemplate } from "../../Modules/programsLayout/fullPageTemplate";
import Contactbg from "../../images/contactusbg.jpg";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import { contactUsSchema } from "../../lib/validationSchema/validation";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import DropdownSelect from "../../components/dropDown";
import { DEFAULT_SERVICES_TEXT, SERVICES_FIELD_OPTIONS } from "../../constants";
import { Button } from "../../components/ui/button";
import { Textarea } from "../../components/ui/textarea";
export default function   ContactUs() {
  let isLoading;
  const form = useForm<z.infer<typeof contactUsSchema>>({
    resolver: zodResolver(contactUsSchema),
    defaultValues: {
      firstname: "",
      lastname: "",
      email: "",
      services: "",
      comments: "",
    },
    mode: "onChange",
  });

  async function onSubmit(values: any) {}
  return (
    <FullPageTemplate
      desktopBg={Contactbg}
      mobileBg={Contactbg}
      bannerTitle={"Contact Us"}
    >
      {isLoading ? (
        <div className="fixed top-0 bottom-0 right-0 left-0 bg-white bg-opacity-50 w-full z-[10] h-full flex justify-center items-center">
          <img
            src="/images/loader.svg"
            width={80}
            height={80}
            alt="Loader"
            className="mx-auto"
          />
        </div>
      ) : null}
      <div className="flex flex-col gap-[30px] max-w-[944px] m-auto">
        <div className={"flex flex-col"}>
          <h2 className="text-[20px] font-GothamBlack  3sx:text-[24px] xs:text-[32px] md:text-[28px] lg:text-[40px] xl:text-[48px]  leading-[25px] 3xs:leading-[30px] xs:leading-[42px] md:leading-[30px] lg:leading-[45px] xl:leading-[50px] text-[#000] m-0 flex items-center mb-5">
            {"We’d like to hear from you!"}
          </h2>
          <p className="font-sans text-[14px]">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </p>
        </div>
        <Form {...form}>
          <form
            className="flex flex-col [&_.error-msg]:text-[12px] [&_.error-msg]:text-[#bf1332] 
        [&_.error-msg]:leading-5 [&_.error-msg]:font-sans [&_.form-label]:text-[14px] 
        [&_.form-label]:font-normal  [&_.form-label]:text-[#4A4F55] [&_.form-label]:font-sans [&_.form-label]:leading-5 [&_.form-itm]:mb-5 [&_.form-checkbox]:my-[10px] [&_.reply-input>input]:placeholder:text-[#4A4F55] [&_.reply-input>input]:placeholder:text-[14px] [&_.form-itm>button>span]:text-[#4A4F55] [&_.form-itm>textarea]:placeholder:text-[#4A4F55] [&_.reply-input>input]:text-[#4A4F55] [&_.form-itm>textarea]:text-[#4A4F55]"
            onSubmit={form.handleSubmit(onSubmit)}
          >
            <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
              <div className="basis-full md:basis-1/2">
                <FormField
                  control={form.control}
                  name="firstname"
                  render={({ field }) => (
                    <FormItem className="form-itm">
                      <FormLabel className="form-label" htmlFor="firstname">
                        First Name
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <Input
                        id="firstname"
                        className={`reply-input ${
                          form.formState.errors.firstname
                            ? "border-[#bf1332]"
                            : "border-[#d6d6d6]"
                        }`}
                        aria-label="please enter your name"
                        placeholder={"Enter your name"}
                        {...field}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />
              </div>
              <div className="basis-full md:basis-1/2">
                <FormField
                  control={form.control}
                  name="lastname"
                  render={({ field }) => (
                    <FormItem className="form-itm">
                      <FormLabel className="form-label" htmlFor="email">
                        Last Name
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <Input
                        id="email"
                        className={`reply-input ${
                          form.formState.errors.lastname
                            ? "border-[#bf1332]"
                            : "border-[#d6d6d6]"
                        }`}
                        aria-label="please enter your email"
                        placeholder={"Enter your name"}
                        {...field}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
              <div className="basis-full md:basis-1/2">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="form-itm">
                      <FormLabel className="form-label" htmlFor="email">
                        Email
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <Input
                        id="email"
                        className={`reply-input ${
                          form.formState.errors.email
                            ? "border-[#bf1332]"
                            : "border-[#d6d6d6]"
                        }`}
                        aria-label="please enter your email"
                        placeholder={"Enter your email address"}
                        {...field}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />
              </div>
              <div className="basis-full md:basis-1/2">
                <FormField
                  control={form.control}
                  name="services"
                  render={({ field }) => (
                    <FormItem
                      className={`form-itm  ${
                        form.formState.errors.services
                          ? "[&>button]:border-[#bf1332]"
                          : "[&>button]:border-[#d6d6d6]"
                      } `}
                    >
                      <FormLabel className="form-label" htmlFor="services">
                        Select Option
                        <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                          *
                        </sup>
                      </FormLabel>
                      <DropdownSelect
                        {...field}
                        id="services"
                        onChange={field.onChange}
                        options={SERVICES_FIELD_OPTIONS}
                        defaultValue={DEFAULT_SERVICES_TEXT}
                        className="min-w-[156px] relative"
                        error={form?.formState?.errors?.services ? true : false}
                      />
                      <FormMessage className="error-msg" />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="basis-full">
              <FormField
                control={form.control}
                name="comments"
                render={({ field }) => (
                  <FormItem className="form-itm">
                    <FormLabel className="form-label" htmlFor="comments">
                      Comments
                      <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                        *
                      </sup>
                    </FormLabel>
                    <Textarea
                      id="comments"
                      className={`rounded-[10px] resize-none h-full min-h-[120px] ${
                        form.formState.errors.comments
                          ? "border-[#bf1332]"
                          : "border-[#d6d6d6]"
                      }`}
                      {...field}
                      placeholder={"Enter Comments"}
                      aria-label="please enter your comment"
                    />
                    <FormMessage className="error-msg" />
                  </FormItem>
                )}
              />
            </div>
            <div className="contact-btn">
              <Button
                type="submit"
                className="uppercase h-[50px] max-w-[124px] md:w-full text-[16px] font-sans font-bold leading-5 rounded-[200px] px-[30px] py-[15px] mt-[12px] md:mt-[10px]"
              >
                Submit
              </Button>
            </div>
          </form>
        </Form>
        {/* {successful ? (
            <div className="mt-[30px] border-2 border-green-600 py-[5px] px-[10px]">
              Thank you for your message. It has been sent.
            </div>
          ) : null} */}
      </div>
    </FullPageTemplate>
  );
}
