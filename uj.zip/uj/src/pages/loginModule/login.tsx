import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "react-router-dom";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import { Button } from "../../components/ui/button";
import * as z from "zod";
import { useState } from "react";
import { Alert, AlertDescription } from "../../components/ui/alert";

import { loginSchema } from "../../lib/validationSchema/validation";

const Login = ({ isPopUp }: any) => {
  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
    mode: "onChange",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword((prevState) => !prevState);
  };
  const onSubmit = () => {};

  return (
    <div className="flex justify-center w-full centered ">
      <div
        className={`max-w-[400px] w-full flex flex-col
           gap-[24px] md:gap-[40px]
        `}
      >
        <div>
          <h2
            className={
              "text-[24px] xs:text-[32px] text-center  md:text-[40px] md:leading-[50px] leading-[35px]  font-sans font-bold text-[#000] mb-[0px]"
            }
          >
            Login
          </h2>
          <p className="font-normal text-[#4A4F55] mt-5">
            Happy to see you again.
            <br /> Login to your account below
          </p>
        </div>
        {error && (
          <Alert variant="destructive" className="bg-[#F8D7DA] text-[#AD2F33]">
            <AlertDescription>
              <span></span>
              {error}
            </AlertDescription>
          </Alert>
        )}
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="[&_.error-msg]:text-[12px]  [&_.error-msg]:text-[#bf1332] 
            [&_.error-msg]:leading-5 [&_.error-msg]:font-sans [&_.reply-input>input]:text-[#4A4F55] [&_.reply-input>input]:placeholder:text-[14px] [&_.form-label]:text-[14px] [&_.form-label]:text-[#4A4F55] [&_.form-label]:font-normal [&_.form-label]:font-sans 
            [&_.form-label]:leading-5 [&_.form-label]:text-start [&_.form-itm]:mb-5 [&_.form-itm]:text-start"
          >
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem className="form-itm">
                  <FormLabel htmlFor="email" className="form-label">
                    Email Address
                    <sup className="text-[#AD2F33] text-[14px] align-text-bottom">
                      *
                    </sup>
                  </FormLabel>

                  <Input
                    id="email"
                    disabled={isLoggingIn}
                    className={`reply-input ${
                      form.formState.errors.email
                        ? "border-[#bf1332]"
                        : "border-[#d6d6d6]"
                    }`}
                    placeholder="Enter Email Address"
                    onFocus={() => setError("")}
                    {...field}
                    onChange={(event: any) => {
                      const inputValue = event.target.value;
                      const cleanedValue =
                        inputValue.length > 0
                          ? inputValue.trimStart()
                          : inputValue; // Trim leading spaces
                      field.onChange(cleanedValue);
                    }}
                  />
                  <FormMessage className="error-msg" />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem className="form-itm">
                  {!isPopUp && (
                    <FormLabel htmlFor="password" className="form-label">
                      Your Password
                      <sup className="text-[#AD2F33] text-[14px] align-text-bottom">
                        *
                      </sup>
                    </FormLabel>
                  )}
                  <Input
                    id="password"
                    disabled={isLoggingIn}
                    className={`reply-input ${
                      form.formState.errors.password
                        ? "border-[#bf1332]"
                        : "border-[#d6d6d6]"
                    }`}
                    placeholder="Password"
                    maxLength={16}
                    onFocus={() => setError("")}
                    {...field}
                    endIcon={
                      <img
                        tabIndex={0}
                        src={require("../../images/login/" +
                          (showPassword ? "show-pass" : "hide-pass") +
                          ".svg")}
                        height={16}
                        width={16}
                        alt="eye"
                        className="cursor-pointer ml-[5px] eyeicon"
                        onClick={togglePasswordVisibility}
                        onKeyDown={(event) => {
                          if (event.key === "Enter") {
                            togglePasswordVisibility();
                          }
                        }}
                      />
                    }
                    type={showPassword ? "text" : "password"}
                    onChange={(event: any) => {
                      const cleanedValue = event.target.value.trim();
                      field.onChange(cleanedValue);
                    }}
                  />
                  <FormMessage className="error-msg" />
                  <p className="bg-[#F4F4F4] text-[12px] p-[10px] rounded-[5px]">
                    Password must contain a minimum of 8 characters, atleast 1
                    letter, 1 number, and 1 special character (!,@,#,$,%,^,&,*).
                  </p>
                </FormItem>
              )}
            />
            <div className="text-end ">
              <Link
                to={"/forgotPassword"}
                className="text-[#D06F1A] text-[14px] leading-[20px]  font-sans font-bold hover:underline"
              >
                Forgot Password?
              </Link>
            </div>
            <div>
              <Button
                type="submit"
                className={`w-full uppercase  font-sans font-bold leading-5 rounded-[200px] text-[16px] h-[50px] my-[30px]
                `}
                disabled={isLoggingIn}
              >
                {isLoggingIn ? `Logging In...` : `Login`}
              </Button>
              <div className="text-center">
                <p className="font-normal text-[#4A4F55]">
                  © 2024 The Beer Store
                </p>
              </div>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
};
export default Login;
