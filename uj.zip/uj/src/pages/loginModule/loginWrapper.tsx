import React from "react";
import Login from "./login";

export default function LoginWrapper() {
  return (
    <div>
      <div className="left-0  split">
        <img
          src={require("../../images/loginBg.jpg")}
          alt={"login"}
          className="h-full object-cover"
        />
      </div>
      <div className="right-0 split ">
        <Login />
      </div>
    </div>
  );
}
