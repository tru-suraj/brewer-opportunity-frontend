import React, { useState } from "react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../../components/ui/tabs";
import { Sliders } from "../../components/sliders";
import PrevButton from "../../components/sliderbutton/sliderPrev";
import NextButton from "../../components/sliderbutton/sliderNext";
import Check from "../../images/check.svg";
import RadioButton from "../../components/radioCheckbox";
import { Button } from "../../components/ui/button";
export default function Cycle({ form }: any) {
  const datesDataForTimeslot = {
    tabsForTimeslot: [
      { id: "1", day: "2024" },
      { id: "2", day: "2025" },
    ],
  };
  const dateSlots = [
    { id: "1", timeslots: ["January 1 - 28", "July 15 - August 11"] },
    {
      id: "2",
      timeslots: ["February 3 - February 29", "August 15 - September 11"],
    },
    { id: "3", timeslots: ["March 6 - April 2", "September 18 - October 15"] },
    { id: "4", timeslots: ["April 9 - May 6", "October 22 - November 18"] },
    { id: "5", timeslots: ["May 13 - June 9", "November 25 - December 22"] },
    { id: "6", timeslots: ["June 16 - July 12", "December 29 - January 25"] },
    {
      id: "7",
      timeslots: ["August 18 - September 14", "February 1 - February 27"],
    },
    { id: "8", timeslots: ["September 21 - October 18", "March 5 - April 1"] },
    { id: "9", timeslots: ["October 25 - November 21", "April 8 - May 5"] },
    { id: "10", timeslots: ["November 28 - December 25", "May 12 - June 8"] },
    { id: "11", timeslots: ["December 29 - January 25", "June 15 - July 11"] },
    {
      id: "12",
      timeslots: ["February 1 - February 27", "July 18 - August 14"],
    },
    { id: "13", timeslots: ["March 6 - April 2", "August 21 - September 17"] },
    { id: "14", timeslots: ["April 9 - May 6", "September 24 - October 21"] },
    { id: "15", timeslots: ["May 13 - June 9", "October 28 - November 24"] },
    { id: "16", timeslots: ["June 16 - July 12", "December 2 - December 29"] },
    {
      id: "17",
      timeslots: ["August 18 - September 14", "January 1 - January 28"],
    },
    {
      id: "18",
      timeslots: ["September 21 - October 18", "February 4 - March 2"],
    },
    { id: "19", timeslots: ["October 25 - November 21", "March 9 - April 5"] },
    { id: "20", timeslots: ["November 28 - December 25", "April 12 - May 9"] },
    { id: "21", timeslots: ["December 29 - January 25", "May 16 - June 12"] },
    { id: "22", timeslots: ["February 1 - February 27", "June 19 - July 15"] },
    { id: "23", timeslots: ["March 6 - April 2", "July 22 - August 18"] },
    { id: "24", timeslots: ["April 9 - May 6", "August 25 - September 21"] },
    { id: "25", timeslots: ["May 13 - June 9", "September 28 - October 25"] },
    { id: "26", timeslots: ["June 16 - July 12", "November 1 - November 28"] },
    {
      id: "27",
      timeslots: ["August 18 - September 14", "December 6 - January 2"],
    },
    {
      id: "28",
      timeslots: ["September 21 - October 18", "January 9 - February 5"],
    },
    {
      id: "29",
      timeslots: ["October 25 - November 21", "February 12 - March 10"],
    },
  ];
  let isFetchingTimeSlots = false;
  return (
    <Tabs className="gap-[32px]">
      <TabsList className="flex flex-row [&_.trigger]:relative [&_.trigger>div]:absolute [&_.trigger>div]:right-[50%] [&_.trigger>div]:top-[-10px] [&_.trigger]:px-[10px] [&_.trigger]:py-[9px] [&_.trigger]:border [&_.trigger]:border-solid [&_.trigger]:rounded-[5px] gap-[10px] [&_.trigger]:basis-1/3 justify-between">
        <FormField
          name="pickupDate"
          control={form.control}
          render={({ field }) => (
            <FormItem className="w-full">
              <FormMessage className="error-msg" />
              <div
                className="flex flex-row gap-y-[20px] !mt-0 gap-x-[10px] md:gap-[10px] md:[&_.slick-slide]:px-[5px] [&_.slick-slide]:px-[5px] [&_.slick-dots]:relative  [&_.slick-dots]:!bottom-[0px]
              [&_.slick-dots]:!mt-[12px]
              [&_.slick-dots]:!mb-[32px]  md:[&_.slick-dots]:!mb-[0px]
              [&_.slick-dots>li>button]:!border-0
              mx-[-7.5px] md:mx-[-8px]
              [&_.prev-slider-img]:!w-[30px]
              [&_.next-slider-img]:!w-[30px]
              [&_.next-slide]:!-right-[10px]
              [&_.prev-slide]:!-left-[10px]
              [&_.slick-list]:!py-[15px]
              [&_.slick-list]:mb-0 xs:[&_.slick-list]:mb-[0px] md:[&_.slick-list]:mb-0"
              >
                {/* <Sliders {...settings}> */}
                {datesDataForTimeslot?.tabsForTimeslot?.map((item) => (
                  <TabsTrigger
                    key={`${item.id}-tabsTrigger`}
                    className="trigger data-[state=active]:border-[#534040] w-[93%] xs:w-full max-w-[133px] hover:bg-[#f4f4f4] hover:[&>p]:text-[#D06F1A]"
                    value={item.id}
                  >
                    <div className="rounded-full bg-[#000] -translate-x-1/2 left-1/2 group-data-[state=inactive]:hidden h-[18px] w-[18px] flex items-center justify-center">
                      <img
                        src={Check}
                        height={8}
                        width={12}
                        alt="green-check"
                        className="m-auto"
                      />
                    </div>
                    <p className="w-full">{item.day}</p>
                  </TabsTrigger>
                ))}{" "}
                {/* </Sliders> */}
              </div>
            </FormItem>
          )}
        />
      </TabsList>
      {dateSlots?.map((item: any) => (
        <TabsContent
          key={`${item.id}-TabsContent`}
          value={item.id}
          className="mt-[5px]"
        >
          {isFetchingTimeSlots ? (
            <div className="p-[50px] text-[16px] text-center">Loading...</div>
          ) : item?.timeslots?.length > 0 ? (
            <FormField
              name="cycle"
              render={() => (
                <FormItem className="pt-[30px] xs:pt-[25px]">
                  <div className="flex flex-wrap flex-row mx-[-15px]">
                    {item?.timeslots.map((timeslot: any) => (
                      <div
                        className={`flex justify-between basis-full md:basis-1/2`}
                        key={timeslot}
                      >
                        <FormField
                          control={form.control}
                          name="cycle"
                          render={({ field }) => {
                            return (
                              <FormItem
                                className={`flex flex-row items-center   my-[5px] mx-[15px]   basis-full border border-solid rounded-[10px] ${
                                  field.value === timeslot
                                    ? "bg-[#f4f4f4]"
                                    : "bg-[#fff]"
                                } [&_span]:w-full [&_label]:w-full [&_label]:px-5 [&_label]:py-[13px] [&_label]:font-bold [&_label]:lg-1200:text-[16px]  [&_label]:mdtab:text-[12px] [&_label]:3xs:text-[16px] [&_label]:text-[12px] [&_label]:cursor-pointer [&_label]:hover:text-[#d06f1a]`}
                              >
                                <FormControl>
                                  <RadioButton
                                    {...field}
                                    selected={field.value?.includes(timeslot)}
                                    id={timeslot}
                                    onSelect={() => {
                                      form.setValue("cycle", timeslot);
                                      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
                                      form.getValues("cycle")
                                        ? form.clearErrors("cycle")
                                        : null;
                                    }}
                                    label={timeslot}
                                  />
                                </FormControl>
                              </FormItem>
                            );
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <FormMessage className="error-msg !w-full" />
                </FormItem>
              )}
            />
          ) : (
            <div className="p-[10px] text-[16px] text-center mt-[30px]">
              No timeslots available
            </div>
          )}
        </TabsContent>
      ))}
    </Tabs>
  );
}
const settings = {
  slidesToShow: 4,
  centerPadding: "0",
  nextArrow: <NextButton />,
  prevArrow: <PrevButton />,
  dots: false,
  infinite: false,
  responsive: [
    {
      breakpoint: 1280,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
      },
    },
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
      },
    },

    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
      },
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 2,
        dots: true,
        nextArrow: false,
        prevArrow: false,
      },
    },
    {
      breakpoint: 375,
      settings: {
        slidesToShow: 1,
        dots: true,
        nextArrow: false,
        prevArrow: false,
      },
    },
  ],
};
