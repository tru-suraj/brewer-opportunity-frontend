import { FullPageTemplate } from "../../Modules/programsLayout/fullPageTemplate";
import { Separator } from "../../components/ui/separator";
import { Form } from "../../components/ui/form";
import { programSchema } from "../../lib/validationSchema/validation";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Dummy from "../../images/dummy.png";
import { Button } from "../../components/ui/button";
import { useForm } from "react-hook-form";
import PersonalDetails from "./personalDetails";
import Cycle from "./cycle";
import Zone from "./zone";
import { useState } from "react";
import InfoCard from "../../components/infoCard";
export default function ProgramDetail() {
  let isLoading;
  const [show, setShow] = useState(false);
  const form = useForm<z.infer<typeof programSchema>>({
    resolver: zodResolver(programSchema),
    defaultValues: {
      brandName: "",
      container: "",
      volume: "",
      packSize: "",
      comments: "",
      articleNumber: "",
      skuPricing: "",
      offers: "",
      promoCase: "",
      cycle: "",
      selectedZone: ["Alcona", "Ajax"],
    },
    mode: "onChange",
  });

  async function onSubmit(values: any) {}
  return (
    <FullPageTemplate>
      <div className="flex flex-col md:flex-row relative pb-[30px] xs:pb-[48px] md:pb-[50px] lg:pb-[60p] xxl:pb-[70px] 2xl:pb-[80px] gap-[30px] md:gap-[60px]">
        <div className=" md:h-auto py-[30px] px-[24px] md:p-0 md:left-0 md:relative md:transition-none md:visible flex-1 md:z-auto md:basis-2/6 lg:basis-[1/4]">
          <div className="main-info md:py-0">
            <InfoCard
              content={
                <div className="mt-8 flex gap-4 flex-col [&_h2]:!text-[14px] [&_div]:flex [&_p]:!text-[14px] [&_h2]:!mb-0">
                  <div>
                    <h2>Selected Cycle:</h2>
                    <p> 6</p>
                  </div>
                  <div>
                    <h2>Selected Store:</h2>
                    <p> {' '}#2106 - Ajax</p>
                  </div>
                </div>
              }
              title={"Flyers & Deals Sponsorship"}
              description={
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim."
              }
              image={{
                url: Dummy,
                alt: "dummy",
                width: 355,
                height: 232,
              }}
              className={`equal-h flex-col flex shadow-none rounded-[10px] border-[1px] overflow-hidden [&_.info-content]:py-[20px] md:[&_.info-content]:!p-[30px]  [&_.info-content]:!px-0 [&_.info-content>div>h2]:mb-[20px] [&_.info-content>div>h2]:!leading-[24px] md:[&_.info-content>div>h2]:!leading-[30px] [&_.info-content>]:.eq-height [&>div>div>a]:font-bold [&>div>div>a]:uppercase [&>div>img]:rounded-[10px] [&_.info-content>div>h2]:text-[16px] md:[&_.info-content>div>h2]:text-[20px] [&_.info-content>div>h2]:font-medium md:[&_.info-content>div>h2]:font-bold 
                            [&_.info-header]:relative
                            [&_.info-header]:overflow-hidden
                            [&_.info-header]:pt-[68%]
                            [&_.info-header]:rounded-[10px]
                            [&>div>img]:absolute [&>div>img]:top-0 [&>div>img]:left-0 [&>div>img]:object-contain
                            [&_.info-title]:max-w-full 3xs:[&_.info-title]:max-w-[250px] md:[&_.info-title]:max-w-full info-height [&_.info-footer]:p-[2px] [&_button]:!w-auto`}
            />
          </div>
        </div>
        <div>
          <Separator orientation="vertical" className="bg-[#d6d6d6]" />
        </div>

        <div className="basis-full md:basis-4/6 lg:basis-[3/4]">
          {isLoading ? (
            <div className="fixed top-0 bottom-0 right-0 left-0 bg-white bg-opacity-50 w-full z-[10] h-full flex justify-center items-center">
              <img
                src="/images/loader.svg"
                width={80}
                height={80}
                alt="Loader"
                className="mx-auto"
              />
            </div>
          ) : null}
          <div className="flex flex-col gap-[30px] max-w-[944px] m-auto">
            <Form {...form}>
              <form
                className="flex flex-col [&_.error-msg]:text-[12px] [&_.error-msg]:text-[#bf1332] 
        [&_.error-msg]:leading-5 [&_.error-msg]:font-sans [&_.form-label]:text-[14px] 
        [&_.form-label]:font-normal  [&_.form-label]:text-[#4A4F55] [&_.form-label]:font-sans [&_.form-label]:leading-5 [&_.form-itm]:mb-5 [&_.form-checkbox]:my-[10px] [&_.reply-input>input]:placeholder:text-[#4A4F55] [&_.form-itm>button>span]:text-[#4A4F55] [&_.form-itm>textarea]:placeholder:text-[#4A4F55] [&_.reply-input>input]:text-[#4A4F55] [&_.form-itm>textarea]:text-[#4A4F55]"
                onSubmit={form.handleSubmit(onSubmit)}
              >
                {!show ? (
                  <div className="flex flex-col gap-10">
                    <div className={"flex flex-col gap-[30px]"}>
                      <div className={"flex flex-col"}>
                        <h2 className="text-[20px] font-GothamMedium 3sx:text-[24px] xs:text-[32px] md:text-[28px] lg:text-[40px] xl:text-[48px]  leading-[25px] 3xs:leading-[30px] xs:leading-[42px] md:leading-[30px] lg:leading-[45px] xl:leading-[50px] text-[#000] m-0 flex items-center mb-5">
                          {"Select Cycle"}
                        </h2>
                        <p className="font-sans text-[14px]">
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua. Ut enim ad minim veniam, quis
                          nostrud exercitation ullamco laboris nisi ut aliquip
                          ex ea commodo consequat.
                        </p>
                      </div>
                      <h2 className="text-[20px] font-GothamMedium md:text-[24px] xs:text-[32px]  md:leading-[30px]  text-[#000] m-0 flex items-center mb-0">
                        {"Select Available Cycle"}
                      </h2>
                      <Cycle form={form} />
                    </div>
                    <Separator
                      orientation="horizontal"
                      className="bg-[#d6d6d6]"
                    />
                    <Zone form={form} />
                  </div>
                ) : (
                  <PersonalDetails form={form} />
                )}
                {/* buttons */}
                <div
                  className={`contact-btn flex mt-10 ${
                    !show ? "justify-end" : "justify-between"
                  }`}
                >
                  {!show ? (
                    <div>
                      <Button
                        type="button"
                        onClick={() => setShow(true)}
                        className="uppercase h-[50px] md:w-full text-[14px] font-sans font-bold leading-5 rounded-[200px] px-[30px] py-[15px]   "
                      >
                        Continue
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <Button
                          type="button"
                          onClick={() => setShow(false)}
                          className="uppercase h-[50px]   md:w-full text-[14px] font-sans font-bold leading-5 rounded-[200px] px-[30px] py-[15px] "
                        >
                          Go back
                        </Button>
                      </div>
                      <div>
                        <Button
                          type="submit"
                          className="uppercase h-[50px]   md:w-full text-[14px] font-sans font-bold leading-5 rounded-[200px] px-[30px] py-[15px]"
                        >
                          Submit
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </form>
            </Form>
            {/* {successful ? (
            <div className="mt-[30px] border-2 border-green-600 py-[5px] px-[10px]">
              Thank you for your message. It has been sent.
            </div>
          ) : null} */}
          </div>
        </div>
      </div>
    </FullPageTemplate>
  );
}
