import React, { useState } from "react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Button } from "../../components/ui/button";
import DownloadIcon from "../../images/downloadIcon.svg";
import { Checkbox } from "../../components/ui/checkbox";
import Close from "../../images/close.svg";
const zones = [
  "Acton",
  "Ajax",
  "Alcona",
  "Alexandria",
  "Almonte",
  "Amherstburg",
  "Amherstview",
  "Ancaster",
  "Aurora",
  "Bancroft",
  "Barrie",
  "Bathurst",
  "Beamsville",
  "Beaverton",
  "Blenheim",
  "Bobcaygeon",
  "Bolton",
  "Bowmanville",
  "Bracebridge",
  "Brampton",
  "Brantford",
  "Bridgenorth",
  "Brockville",
  "Brooklin",
  "Burlington",
  "Caledon",
  "Caledonia",
  "Cambridge",
  "Campbellford",
  "Carleton Place",
  "Chatham",
  "Chelmsford",
  "Cobourg",
  "Collingwood",
  "Concord",
  "Cornwall",
  "Courtice",
  "Creemore",
  "Deep River",
  "Don Mills",
];

export default function Zone({ form }: any) {
  const [zone, setZone] = useState(zones);
  const [loadMore, setLoadMore] = useState(8);
  return (
    <div className="flex flex-col gap-[40px]">
      <div className="flex flex-col gap-[30px]">
        <div className="flex gap-5 justify-start">
          <h2 className="mb-0">Select Zone</h2>
          <Button className="rounded-[30px] gap-[10px]">
            Download Guide
            <span>
              <img
                src={DownloadIcon}
                width={10}
                height={14}
                alt="DownloadIcon"
              />
            </span>
          </Button>
        </div>
        <div>
          <h2 className="text-[14px] mb-5">Selected zone:</h2>
          <div className="flex flex-wrap gap-[10px]">
            {form.watch("selectedZone").length <= 0 && (
              <p>No zone is selected</p>
            )}
            {form.watch("selectedZone")?.map((itm: any, idx: number) => (
              <div
                key={`zone${idx}`}
                className="flex flex-row gap-[5px] py-[6px] px-[10px] border-[1px] border-[#d6d6d6] rounded-[5px] bg-[#f4f4f4]"
              >
                <p className="text-[#000]">{itm}</p>
                <Button
                  onClick={() =>
                    form.setValue("selectedZone", [
                      ...form
                        .watch("selectedZone")
                        .filter((zone: string) => zone !== itm),
                    ])
                  }
                  className="p-0 h-auto"
                  variant={"ghost"}
                >
                  <img src={Close} height={12} width={12} alt="close" />
                </Button>
              </div>
            ))}
            {form.watch("selectedZone")?.length > 0 && (
              <Button
                onClick={() => form.setValue("selectedZone", [])}
                variant={"ghost"}
                className={
                  "p-0 !text-[#D06F1A] font-GothamMedium  hover:!text-[#D06F1A] hover:underline  h-auto"
                }
              >
                Clear All
              </Button>
            )}
          </div>
        </div>
      </div>
      <FormField
        control={form.control}
        name="selectedZone"
        render={() => (
          <FormItem className="flex flex-wrap flex-row mx-[-15px]">
            {zone.slice(0, loadMore).map((item: string) => (
              <div
                className={`flex justify-between basis-full md:basis-1/2 !mt-0`}
                key={item}
              >
                <FormField
                  control={form.control}
                  name="selectedZone"
                  render={({ field }) => {
                    return (
                      <FormItem
                        key={item}
                        className={`flex flex-row selectedZone-center   my-[5px] mx-[15px]   basis-full border border-solid rounded-[10px] ${
                          field.value.includes(item)
                            ? "bg-[#f4f4f4]"
                            : "bg-[#fff]"
                        } [&_span]:w-full [&_label]:w-full [&_label]:p-5  [&_label]:font-bold [&_label]:lg-1200:text-[16px]  [&_label]:mdtab:text-[12px] [&_label]:3xs:text-[16px] [&_label]:text-[12px] [&_label]:cursor-pointer [&_label]:hover:text-[#d06f1a]`}
                      >
                        <FormLabel className="font-normal !mt-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(item)}
                              onCheckedChange={(checked) => {
                                return checked
                                  ? field.onChange([...field.value, item])
                                  : field.onChange(
                                      field.value?.filter(
                                        (value: string) => value !== item
                                      )
                                    );
                              }}
                            />
                          </FormControl>
                          {item}
                        </FormLabel>
                      </FormItem>
                    );
                  }}
                />
              </div>
            ))}
            <FormMessage className="error-msg !w-full ml-[15px]" />
          </FormItem>
        )}
      />
      {zone?.length <= loadMore ? (
        <div className="text-center">
          <Button
            variant={"ghost"}
            onClick={() => setLoadMore(8)}
            className={
              "p-0 !text-[#D06F1A] font-GothamMedium mt-[-10px]  hover:!text-[#D06F1A] hover:underline  h-auto"
            }
          >
            Show less
          </Button>
        </div>
      ) : (
        <div className="text-center">
          <Button
            variant={"ghost"}
            onClick={() => setLoadMore((prev) => prev + 8)}
            className={
              "p-0 !text-[#D06F1A] font-GothamMedium mt-[-10px]  hover:!text-[#D06F1A] hover:underline  h-auto"
            }
          >
            Load more zone
          </Button>
        </div>
      )}
    </div>
  );
}
