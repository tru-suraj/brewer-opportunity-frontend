import React from "react";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../../components/ui/form";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { PACKED_SIZE_OTIONS } from "../../constants";
import DropdownSelect from "../../components/dropDown";
export default function PersonalDetails({ form }: any) {
  return (
    <>
     <h2 className="mb-5">Promotional Details</h2>
      <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="brandName"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="brandName">
                  Brand Name
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="brandName"
                  className={`reply-input ${
                    form.formState.errors.brandName
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  aria-label="please enter your name"
                  placeholder={"Enter your name"}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="packSize"
            render={({ field }) => (
              <FormItem
                className={`form-itm  ${
                  form.formState.errors.packSize
                    ? "[&>button]:border-[#bf1332]"
                    : "[&>button]:border-[#d6d6d6]"
                } `}
              >
                <FormLabel className="form-label" htmlFor="packSize">
                  Pack Size
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <DropdownSelect
                  {...field}
                  id="packSize"
                  onChange={field.onChange}
                  options={PACKED_SIZE_OTIONS}
                  defaultValue={"Select Pack size"}
                  className="min-w-[156px] relative"
                  error={form?.formState?.errors?.packSize ? true : false}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="volume"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="volume">
                  Volume
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="Volume"
                  className={`reply-input ${
                    form.formState.errors.volume
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="container"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="container  ">
                  Container
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="container"
                  className={`reply-input ${
                    form.formState.errors.container
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
      </div>
      <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="articleNumber"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="articleNumber">
                  Article Number
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="articleNumber"
                  className={`reply-input ${
                    form.formState.errors.articleNumber
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="skuPricing"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="container  ">
                  SKU Pricing
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="skuPricing"
                  className={`reply-input ${
                    form.formState.errors.skuPricing
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
      </div>
      <div className="flex md:flex-row flex-col xs:gap-[0px] md:gap-[30px]">
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="offers"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="offers">
                  Offers
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="offers"
                  className={`reply-input ${
                    form.formState.errors.offers
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
        <div className="basis-full md:basis-1/2">
          <FormField
            control={form.control}
            name="promoCase"
            render={({ field }) => (
              <FormItem className="form-itm">
                <FormLabel className="form-label" htmlFor="container  ">
                  Promo Case
                  {/* <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
              *
            </sup> */}
                </FormLabel>
                <Input
                  id="skuPricing"
                  className={`reply-input ${
                    form.formState.errors.promoCase
                      ? "border-[#bf1332]"
                      : "border-[#d6d6d6]"
                  }`}
                  {...field}
                />
                <FormMessage className="error-msg" />
              </FormItem>
            )}
          />
        </div>
      </div>
      <div className="basis-full [&>div]:!mb-0">
        <FormField
          control={form.control}
          name="comments"
          render={({ field }) => (
            <FormItem className="form-itm">
              <FormLabel className="form-label" htmlFor="comments">
                Advertising Summary
                <sup className="text-[#AD2F33] text-[15px] align-text-bottom">
                  *
                </sup>
              </FormLabel>
              <Textarea
                id="comments"
                className={`rounded-[10px] resize-none h-full min-h-[160px] ${
                  form.formState.errors.comments
                    ? "border-[#bf1332]"
                    : "border-[#d6d6d6]"
                }`}
                {...field}
                aria-label="please enter your comment"
              />
              <FormMessage className="error-msg" />
            </FormItem>
          )}
        />
      </div>
    </>
  );
}
