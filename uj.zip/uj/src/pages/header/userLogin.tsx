import React from "react";
import { Button } from "../../components/ui/button";
import { useNavigate } from "react-router-dom";
import UserIcon from '../../images/usericon.svg'
export default function UserLogin() {
  const navigate = useNavigate();
  return (
    <div>
      <div>
        <div className={"flex appearance-none"}>
          <Button
            className="text-white bg-transparent text-[14px] font-sans font-normal flex md:items-center border-2 border-solid border-white rounded-full h-auto w-auto  pt-[11px] pb-[10px] px-[20px] gap-[10px]"
            size={"icon"}
            variant="link"
            onClick={() => navigate("/login")}
          >
            <img src={UserIcon} alt="user" />

            <p className="font-sans text-[#fff] text-[16px] leading-[1.2] font-medium xl:block hidden">
              {true ? "Login" : `Amandeep`}
            </p>
          </Button>
        </div>
      </div>
    </div>
  );
}
