import React from "react";
import UserLogin from "./userLogin";
import BeerStoreIcon from "../../images/beerlogo.svg";
import { Link } from "react-router-dom";
export default function Header() {
  return (
    <div className="py-5 px-20 bg-[#000]">
      <div className="flex justify-between">
        <div>
          <Link to={"/"}>
            <img src={BeerStoreIcon} alt={"beerlogo"} />
          </Link>
        </div>
        <UserLogin />
      </div>
    </div>
  );
}
