import React from "react";
import { Link } from "react-router-dom";

export default function Fotter() {
  return (
    <section>
      <div className="bg-secondary">
        <div className="container py-10 ">
          <div className="flex justify-between">
            <div className="text-center">
              <p className="font-normal text-[14px] text-[#fff]">
                © 2024 The Beer Store
              </p>
            </div>
            <div>
              <ul className="[&_li]:font-normal [&_li]:text-[14px] [&_li]:text-[#fff] [&_li]:float-left gap-5 flex">
                <li><Link to={'https://thebeerstore.ca/'} target='_blank'>TheBeerStore.ca</Link></li>
                <li>FAQ</li>
                <li><Link to={'/contactUs'}>Contact</Link></li>
                <li><Link to={'/termsConditon'}>Terms & Conditions</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
