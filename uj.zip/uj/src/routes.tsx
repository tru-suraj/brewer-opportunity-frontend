import React from "react";
import { Route, Routes } from "react-router-dom";
import LoginWrapper from "./pages/loginModule/loginWrapper";
import Home from "./pages/landingPage";
import ForgotPassword from "./pages/forgotPassword";
import ResetPassword from "./pages/resetPassword";
import NotFound from "./pages/notFound";
import ThankYouMessage from "./pages/thankyou";
import Programs from "./pages/programs";
import ContactUs from "./pages/contactUs";
import TermsConditon from "./pages/termsConditon";
import ProgramDetail from "./pages/programDetail";
const createRoutes = () => (
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="*" element={<NotFound />} />
    <Route path="/login" element={<LoginWrapper />} />
    <Route path="/forgotPassword" element={<ForgotPassword />} />
    <Route path="/thankyou" element={<ThankYouMessage />} />
    <Route path="/resetPassword" element={<ResetPassword />} />
    <Route path="/programs" element={<Programs />} />
    <Route path="/programs/:id" element={<ProgramDetail />} />
    <Route path="/contactUs" element={<ContactUs />} />
    <Route path="/termsConditon" element={<TermsConditon />} />
  </Routes>
);
export default createRoutes;
