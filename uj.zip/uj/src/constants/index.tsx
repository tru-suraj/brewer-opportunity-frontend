export const SERVICES_FIELD_OPTIONS = [
  {
    optionname: "Thebeerstore.ca Inquiry",
    optionval: "Thebeerstore.ca Inquiry",
  },
  { optionname: "Mobile App inquiry", optionval: "Mobile App inquiry" },
  { optionname: "Social Media Inquiry", optionval: "Social Media Inquiry" },
  { optionname: "Retail Stores Inquiry", optionval: "Retail Stores Inquiry" },
  {
    optionname: "Customer Service Inquiry",
    optionval: "Customer Service Inquiry",
  },
  { optionname: "BDL Inquiry", optionval: "BDL Inquiry" },
  { optionname: "Beer for Business", optionval: "Beer for Business" },
  { optionname: "Media Inquiry", optionval: "Media Inquiry" },
  { optionname: "Other", optionval: "Other" },
];
export const DEFAULT_SERVICES_TEXT = "Choose an option";
export const PACKED_SIZE_OTIONS = [
  { optionname: "Single Pack", optionval: "Single Pack" },
  { optionname: "6", optionval: "6" },
  { optionname: "12", optionval: "12" },
  { optionname: "24", optionval: "24" },
  { optionname: "30", optionval: "30" },
  { optionname: "36", optionval: "36" },
  { optionname: "48", optionval: "48" },
];
