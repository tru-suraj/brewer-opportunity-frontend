import React from "react";
import "./App.css";
import Login from "./pages/loginModule/login";
import createRoutes from "./routes";
function App() {
  const content = createRoutes();
  return content;
}

export default App;
