import React, { useState, forwardRef, useEffect } from "react";
import CheckBlack from "../images/check-black.svg";
import Check from "../images/check.svg";
interface CheckboxProps {
  label: React.ReactNode;
  checked: boolean;
  checkBlack?: boolean;
  id: string;
  onChange: (checked: boolean) => void;
}

// eslint-disable-next-line react/display-name
const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>((props, ref) => {
  const { label, id, onChange, checked, checkBlack } = props;
  const [isChecked, setChecked] = useState(checked);
  useEffect(() => {
    setChecked(checked);
  }, [checked]);
  // Use state for checked state
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = e.target.checked;
    setChecked(isChecked); // Update local state
    onChange(isChecked);
  };
  return (
    <label
      htmlFor={id}
      className="relative flex  gap-[8px]  text-[14px] font-nromal leading-[22px]  peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
    >
      <div className="mt-1">
        <input
          className={`appearance-none rounded-[5px] h-[18px] w-[18px] bg-[#fff] border-[1px] border-[#d6d6d6]  ${
            !checkBlack ? "checked:bg-[#000]" : "checked:bg-[#f4b233]"
          } ${
            checkBlack ? "checked:border-[#f4b233]" : "checked:border-[#000]"
          }  focus:outline-none`}
          type={"checkbox"}
          checked={isChecked}
          id={id}
          name={id}
          onChange={handleChange}
          ref={ref}
        />
        {isChecked && (
          <img
            src={checkBlack ? CheckBlack : Check}
            height={12}
            width={12}
            alt="check"
            className="absolute  top-[9px] left-[3px]"
          />
        )}
      </div>

      {label}
    </label>
  );
});

export default Checkbox;
