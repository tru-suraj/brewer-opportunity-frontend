import ArrowNext from "../../images/Arrow-next.svg";

function NextButton(props: any) {
  const { onClick, disabled, style } = props;
  return (
    <div
      className={`absolute right-[-10px] translate-y-[-50%] top-[50%] next-slide cursor-pointer next-slider-btn ${
        disabled ? "opacity-40" : "opacity-100"
      }`}
      style={{ ...style }}
      onClick={onClick}
      onKeyDown={(event) => {
        if (event.key === "Enter") {
          onClick();
        }
      }}
    >
      <img
        src={ArrowNext}
        alt="next"
        width={48}
        height={48}
        className={`next-slider-img max-w-none customtabIndex`}
        tabIndex={0}
      />
    </div>
  );
}

export default NextButton;
