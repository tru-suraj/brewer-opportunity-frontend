  import ArrowPrev from '../../images/Arrow-prev.svg'
function PrevButton(props: any) {
  const { onClick, disabled, style } = props;
  return (
    <div

      className={
        `absolute left-[-10px] top-[50%] translate-y-[-50%] before:'' prev-slide z-[1] cursor-pointer ${disabled ? 'opacity-40' : 'opacity-100'}`
      }
      style={{ ...style }}
      onClick={onClick}
      onKeyDown={(event) => {
        if (event.key === 'Enter') {
          onClick();
        }
      }}
    >
      <img
        src={
          ArrowPrev
        }
        alt="prev"
        width={48}
        height={48}
        className="prev-slider-img max-w-none customtabIndex"
        tabIndex={0}
      />
    </div>
  );
}

export default PrevButton;
