import React from "react";
import GreenCheck from "../../images/greenCheck.svg";
import { Button } from "./button";
import { useNavigate } from "react-router-dom";
export default function ThankYou({ className }: any) {
  const navigate = useNavigate();
  return (
    <div className={`max-w-[700px] m-auto ${className}`}>
      <div className="flex flex-col items-center gap-[30px] border-[1px] rounded-[10px] px-[40] py-[60px]">
        <div>
          <img src={GreenCheck} alt="check" />
        </div>
        <div className="flex flex-col items-center gap-[10px]">
          <h2 className="text-[40px] font-GothamBold leading-[50px]">
            Thank You
          </h2>
          <p className="text-[#4A4F55] font-sans text-center text-[16px]">
            Your application has been successfully submitted.
            <br />
            The Brewer Programs Team will be in touch to confirm your
            application.
          </p>
        </div>
        <div>
          <Button
            onClick={() => navigate("/")}
            className="rounded-[30px]  uppercase"
          >
            Back To home page
          </Button>
        </div>
      </div>
    </div>
  );
}
