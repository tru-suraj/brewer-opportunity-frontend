import React from 'react';
import Slider from 'react-slick';
// import 'slick-carousel/slick/slick.css';
// import 'slick-carousel/slick/slick-theme.css';

interface SlidersProps {
  className?: string;
  children: React.ReactNode;
}

export const Sliders: React.FC<SlidersProps> = ({
  className,
  children,
  ...rest
}) => {
  return (
    <Slider className={className} {...rest}>
      {children}
    </Slider>
  );
};
