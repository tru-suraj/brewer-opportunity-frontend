import * as React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Button } from "../components/ui/button";
import { cn } from "../lib/utils";
import { Badge } from "../components/ui/badge";

import { Link } from "react-router-dom";
import EqualHeight from "../lib/equalHeight";
import FeatueBadge from "../images/featureBadge.svg";
interface InfoCardProps {
  title: string;
  description?: string | JSX.Element;
  content?: string | JSX.Element;
  image?: {
    url: string;
    alt: string;
    width: number | `${number}` | any;
    height: number | `${number}` | any;
  };
  buttonText?: string;
  badgeText?: string;
  buttonIcon?: JSX.Element;
  onClickButton?: () => void;
  className?: string | undefined;
  asLink?: boolean;
  buttonLink?: string | undefined;
  from?: string;
  buttonTarget?: string;
  buttonAriaLabel?: string;
  index?: number;
}

const InfoCard = ({
  title,
  description,
  image,
  content,
  buttonText,
  onClickButton,
  badgeText,
  buttonIcon,
  className,
  asLink,
  buttonLink,
  from,
  index,
  buttonAriaLabel,
  buttonTarget,
}: InfoCardProps) => {
  EqualHeight("main-info", "info-height");
  //   const datalayer = useDataLayer();

  const bagColor = [
    "Digital",
    "Planning Tools",
    "Sale of data",
    "External Advertising",
    "Bolton Exclusive",
    "Retail",
  ].includes(badgeText || "")
    ? "#4A4F55"
    : "#406325";
  return (
    <Card
      //   onClick={onCardSelect}
      className={cn(
        " flex flex-col border border-solid rounded-[10px] relative overflow-hidden",
        className
      )}
    >
      <CardHeader className="info-header">
        {image && (
          // <Link to={buttonLink || ""} className="pt-0">
            <img
              src={image?.url}
              alt={image?.alt}
              width={image?.width}
              height={image?.height}
              style={{
                width: "100%",
                height: "auto",
              }}
              className="info-image"
            />
          // </Link>
        )}
      </CardHeader>

      <CardContent className="py-4 px-2 info-content !p-[20px] xsm:!p-[30px]">
        {title && (
          <div>
            <CardTitle className="eq-height text-[20px] leading-[25px] 2xs:leading-[30px] font-sans font-bold info-title eq-height tracking-[0.16px] mb-[20px]">
              {title}
            </CardTitle>
          </div>
        )}
        {description && (
          <div>
            <CardDescription className="mb-[20px] text-[13px] font-sans font-normal eq-height info-description ">
              {description}
            </CardDescription>
          </div>
        )}
        {badgeText && (
          <Badge
            variant={["Featured"].includes(badgeText) ? "secondary" : "default"}
            className={`info-badge   rounded-[30px] uppercase gap-[5px] text-[#fff] hover:bg-White px-2 py-1 leading-4 justify-center absolute right-4 top-4`}
          >
            {["Featured"].includes(badgeText) && (
              <img
                src={FeatueBadge}
                alt="featureBadge"
                height={12}
                width={12}
              />
            )}
            {badgeText}
          </Badge>
        )}

        {content}
        <CardFooter className="flex p-0 info-footer">
          {buttonText && (
            <Button
              asChild={asLink}
              className={`${
                asLink ? "tbs-link-text p-0 h-auto " : "w-full rounded-[100px]"
              } text-[11px] font-sans font-bold`}
              onClick={onClickButton}
              variant={asLink ? "link" : "default"}
            >
              <>
                {asLink ? (
                  <Link
                    to={`${buttonLink}`}
                    className={"p-0 text-[#D06F1A] hover:underline"}
                    target={buttonTarget ? "_blank" : "_self"}
                    aria-label={buttonAriaLabel}
                  >
                    {buttonText}
                  </Link>
                ) : (
                  buttonText
                )}
                {buttonIcon}
              </>
            </Button>
          )}
        </CardFooter>
      </CardContent>
    </Card>
  );
};

export default InfoCard;
